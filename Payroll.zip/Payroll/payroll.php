<?php
declare(strict_types=1);

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function i($v): string {
    return (string) intval($v);
}

// Demo data to match the UI screenshot.
$stats = [
    'total_employees' => 45,
    'on_leave' => 3,
    'processing' => 2,
];

$notificationCount = 2;

$assignedSites = [
    'main-street' => [
        'name' => 'Main Street Project',
        'workers' => 15,
        'attendance_present' => 12,
        'attendance_total' => 15,
    ],
    'downtown' => [
        'name' => 'Downtown Office Complex',
        'workers' => 10,
        'attendance_present' => 8,
        'attendance_total' => 10,
    ],
];
$sitePayrollData = [
    'main-street' => [
        'name' => 'Main Street Project',
        'period' => 'Oct 1-15, 2023',
        'workers' => [
            [ 'name' => 'Juan Dela Cruz', 'role' => 'Foreman', 'days' => 12, 'gross' => 9800, 'deductions' => 1200, 'status' => 'Ready' ],
            [ 'name' => 'Mark Santos', 'role' => 'Carpenter', 'days' => 11, 'gross' => 7700, 'deductions' => 900, 'status' => 'Ready' ],
            [ 'name' => 'Paolo Reyes', 'role' => 'Mason', 'days' => 12, 'gross' => 8200, 'deductions' => 1000, 'status' => 'Ready' ],
            [ 'name' => 'Leo Garcia', 'role' => 'Laborer', 'days' => 10, 'gross' => 6100, 'deductions' => 700, 'status' => 'Ready' ],
            [ 'name' => 'Ryan Flores', 'role' => 'Electrician', 'days' => 12, 'gross' => 9500, 'deductions' => 1100, 'status' => 'Ready' ],
        ],
    ],
    'downtown' => [
        'name' => 'Downtown Office Complex',
        'period' => 'Oct 1-15, 2023',
        'workers' => [
            [ 'name' => 'Allan Cruz', 'role' => 'Foreman', 'days' => 12, 'gross' => 9200, 'deductions' => 900, 'status' => 'Ready' ],
            [ 'name' => 'Kevin Lim', 'role' => 'Carpenter', 'days' => 11, 'gross' => 7400, 'deductions' => 800, 'status' => 'Ready' ],
            [ 'name' => 'Jerome Tan', 'role' => 'Mason', 'days' => 10, 'gross' => 6600, 'deductions' => 700, 'status' => 'Ready' ],
            [ 'name' => 'Noel Dizon', 'role' => 'Laborer', 'days' => 12, 'gross' => 7100, 'deductions' => 750, 'status' => 'Ready' ],
            [ 'name' => 'Paolo Uy', 'role' => 'Plumber', 'days' => 11, 'gross' => 6900, 'deductions' => 650, 'status' => 'Ready' ],
        ],
    ],
];
// Try load data from MySQL (if configured). If it fails, keep demo data.
try {
    require_once __DIR__ . '/lib/repo.php';
    $pdo = db();
    $stats = repo_stats($pdo);
    $assignedSites = repo_assigned_sites($pdo);
    $sitePayrollData = repo_site_payroll_data($pdo);
} catch (Throwable $e) {
    // Keep demo data.
}?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Philippians CDO - Payroll</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 200px;
            background: linear-gradient(135deg, #c8652f 0%, #9a4f22 100%);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 20px 25px;
            font-size: 18px;
            font-weight: 700;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            margin-bottom: 25px;
            letter-spacing: 0.5px;
        }

        .sidebar-section {
            margin-bottom: 25px;
            padding: 0 12px;
        }

        .sidebar-section-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.5);
            padding: 0 8px 10px;
            letter-spacing: 0.8px;
        }

        .sidebar-item {
            display: flex;
            align-items: center;
            padding: 11px 12px;
            margin-bottom: 6px;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.9);
            transition: all 0.25s ease;
            font-size: 13px;
            font-weight: 500;
        }

        .sidebar-item:hover {
            background-color: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .sidebar-item.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            font-weight: 600;
        }

        .sidebar-item i {
            margin-right: 12px;
            width: 16px;
            text-align: center;
            font-size: 15px;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px;
            flex: 1;
            padding: 25px 35px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 25px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .page-title {
            font-size: 26px;
            font-weight: 700;
            color: #2c3e50;
            letter-spacing: -0.5px;
        }

        .page-subtitle {
            font-size: 13px;
            color: #9ca3af;
            margin-top: 5px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .payroll-view[hidden] {
            display: none !important;
        }

        .site-header-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 18px;
            flex-wrap: wrap;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 12px;
            border-radius: 8px;
            background: white;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
            color: #374151;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }

        .site-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid transparent;
            cursor: pointer;
            font-weight: 700;
            font-size: 12px;
            letter-spacing: 0.3px;
            text-transform: uppercase;
            transition: transform 0.2s ease, box-shadow 0.2s ease, filter 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn:hover {
            transform: translateY(-1px);
            filter: brightness(0.98);
        }

        .action-btn.primary {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
            box-shadow: 0 2px 10px rgba(40, 167, 69, 0.18);
        }

        .action-btn.secondary {
            background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
            color: white;
            box-shadow: 0 2px 10px rgba(245, 124, 0, 0.18);
        }

        .action-btn.info {
            background: linear-gradient(135deg, #2196F3 0%, #1565c0 100%);
            color: white;
            box-shadow: 0 2px 10px rgba(33, 150, 243, 0.18);
        }

        .site-title {
            margin-bottom: 18px;
        }

        .site-name {
            font-size: 18px;
            font-weight: 800;
            color: #111827;
            letter-spacing: -0.2px;
        }

        .site-period {
            font-size: 12px;
            color: #9ca3af;
            margin-top: 5px;
        }

        .site-summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .summary-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .summary-label {
            font-size: 11px;
            color: #9ca3af;
            font-weight: 600;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        .summary-value {
            font-size: 26px;
            color: #111827;
            font-weight: 800;
            font-variant-numeric: tabular-nums;
        }

        .site-table-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }

        .site-table-title {
            font-size: 15px;
            font-weight: 800;
            color: #2c3e50;
            margin-bottom: 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
        }

        .site-table-subtitle {
            font-size: 12px;
            color: #9ca3af;
            font-weight: 600;
        }

        .site-table-wrap {
            overflow-x: auto;
            border-radius: 10px;
            border: 1px solid #eef2f7;
        }

        .site-payroll-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 760px;
            background: white;
            font-size: 13px;
        }

        .site-payroll-table th {
            text-align: left;
            padding: 12px 12px;
            color: #6b7280;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: #fafbfc;
            border-bottom: 1px solid #e5e7eb;
            white-space: nowrap;
        }

        .site-payroll-table td {
            padding: 12px 12px;
            border-bottom: 1px solid #f1f5f9;
            color: #111827;
            vertical-align: middle;
        }

        .site-payroll-table tbody tr:hover {
            background: #f8fafc;
        }

        .site-payroll-table .center {
            text-align: center;
        }

        .site-payroll-table .right {
            text-align: right;
            font-variant-numeric: tabular-nums;
        }

        .site-payroll-table .pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 0.3px;
            text-transform: uppercase;
            border: 1px solid rgba(0,0,0,0.06);
            background: #f8fafc;
            color: #334155;
            white-space: nowrap;
        }

        .site-payroll-table tfoot td {
            font-weight: 900;
            border-top: 2px solid #e5e7eb;
            background: #fafafa;
        }

        .success-banner {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 10px;
            padding: 14px 16px;
            margin-top: 18px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .success-banner i {
            color: #28a745;
            font-size: 18px;
        }

        .success-banner .msg {
            color: #155724;
            font-weight: 650;
            font-size: 13px;
            flex: 1;
        }

        .success-banner a {
            color: #1565c0;
            font-weight: 800;
            text-decoration: none;
            font-size: 12px;
            white-space: nowrap;
        }

        .success-banner a:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
                padding: 15px 0;
            }

            .sidebar-header {
                font-size: 12px;
                padding: 0 5px;
            }

            .sidebar-item {
                justify-content: center;
                padding: 11px 5px;
            }

            .sidebar-item span {
                display: none;
            }

            .main-content {
                margin-left: 60px;
                padding: 15px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .header-right {
                width: 100%;
                justify-content: flex-start;
            }

            .site-summary-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">Philippians CDO</div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Overview</div>
                <a href="payroll.php" class="sidebar-item active">
                    <i class="fas fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Operations</div>
                <a href="payroll-process.php" class="sidebar-item">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Payroll Processing</span>
                </a>
                <a href="attendance.php" class="sidebar-item">
                    <i class="fas fa-calendar-check"></i>
                    <span>Attendance</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Workforce</div>
                <a href="worker.php" class="sidebar-item">
                    <i class="fas fa-users"></i>
                    <span>Worker</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Reports</div>
                <a href="report.php" class="sidebar-item">
                    <i class="fas fa-file-csv"></i>
                    <span>Payroll Report</span>
                </a>
                <a href="#" class="sidebar-item">
                    <i class="fas fa-history"></i>
                    <span>History</span>
                </a>
                <a href="#" class="sidebar-item">
                    <i class="fas fa-archive"></i>
                    <span>Archive</span>
                </a>
            </div>

            <div class="sidebar-section">
                <a href="#" class="sidebar-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div>
                    <div class="page-title">Payroll</div>
                    <div class="page-subtitle">Manage pay process and project payroll</div>
                </div>
                <div class="header-right">
                    <i class="fas fa-bell" style="font-size: 20px; cursor: pointer; color: #ff6b6b; position: relative;">
                        <span style="position: absolute; background: #ff6b6b; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: bold; top: -8px; right: -8px;"><?= i($notificationCount) ?></span>
                    </i>
                    <div style="background: linear-gradient(135deg, #f5f7fa 0%, #f0f3f7 100%); padding: 10px 18px; border-radius: 6px; color: #555; font-size: 13px; display: flex; align-items: center; gap: 10px; border: 1px solid #e5e7eb; font-weight: 500;">
                        <i class="fas fa-user" style="font-size: 15px; color: #666;"></i>
                        <span>Payroll Staff</span>
                    </div>
                </div>
            </div>

            <div id="view-dashboard" class="payroll-view">
            <!-- Overview Cards -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 22px; margin-bottom: 30px;">
                <!-- Total Employees -->
                <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); display: flex; align-items: center; gap: 18px;">
                    <div style="width: 65px; height: 65px; border-radius: 10px; background-color: #fff4e6; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ff9800;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #9ca3af; font-weight: 500; margin-bottom: 8px; text-transform: uppercase;">Total Employees</div>
                        <div style="font-size: 32px; color: #1f2937; font-weight: 700;"><?= i($stats["total_employees"]) ?></div>
                    </div>
                </div>

                <!-- On Leave -->
                <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); display: flex; align-items: center; gap: 18px;">
                    <div style="width: 65px; height: 65px; border-radius: 10px; background-color: #fff4e6; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ff9800;">
                        <i class="fas fa-calendar-times"></i>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #9ca3af; font-weight: 500; margin-bottom: 8px; text-transform: uppercase;">On Leave</div>
                        <div style="font-size: 32px; color: #1f2937; font-weight: 700;"><?= i($stats["on_leave"]) ?></div>
                    </div>
                </div>

                <!-- Processing -->
                <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); display: flex; align-items: center; gap: 18px;">
                    <div style="width: 65px; height: 65px; border-radius: 10px; background-color: #e8f5e9; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #4caf50;">
                        <i class="fas fa-hourglass-end"></i>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #9ca3af; font-weight: 500; margin-bottom: 8px; text-transform: uppercase;">Processing</div>
                        <div style="font-size: 32px; color: #1f2937; font-weight: 700;"><?= i($stats["processing"]) ?></div>
                    </div>
                </div>
            </div>

            <!-- Construction Sites Section -->
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 30px;">
                <div style="font-size: 16px; font-weight: 700; color: #2c3e50; margin-bottom: 25px;">Construction Sites Assigned</div>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px;">
                    
                    <!-- Main Street Project -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 10px; padding: 22px; background: #fafbfc; cursor: pointer; transition: all 0.3s ease;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
                            <div style="display: flex; align-items: center; gap: 12px; font-weight: 600; color: #2c3e50; font-size: 14px;">
                                <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #ffe5cc 0%, #ffd9b3 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #ff9800; font-size: 20px;">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div><?= h($assignedSites["main-street"]["name"]) ?></div>
                            </div>
                            <div style="background: #d4edda; color: #155724; padding: 5px 13px; border-radius: 5px; font-size: 10px; font-weight: 700;">ACTIVE</div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; font-size: 13px;">
                            <div style="color: #555;">
                                <div style="color: #9ca3af; font-size: 11px; margin-bottom: 5px; text-transform: uppercase; font-weight: 600;">Workers:</div>
                                <div style="font-weight: 700; color: #1f2937; font-size: 16px;"><?= i($assignedSites["main-street"]["workers"]) ?></div>
                            </div>
                            <div style="color: #555;">
                                <div style="color: #9ca3af; font-size: 11px; margin-bottom: 5px; text-transform: uppercase; font-weight: 600;">Today's attendance:</div>
                                <div style="font-weight: 700; color: #1f2937; font-size: 16px;"><?= i($assignedSites["main-street"]["attendance_present"]) ?>/<?= i($assignedSites["main-street"]["attendance_total"]) ?></div>
                            </div>
                        </div>
                        <button style="width: 100%; padding: 11px 16px; background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; transition: all 0.3s ease;" onclick="window.location.href='attendance.php#main-street';">
                            <i class="fas fa-arrow-right" style="margin-right: 8px;"></i>View Attendance Records
                        </button>
                    </div>

                    <!-- Downtown Office Complex -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 10px; padding: 22px; background: #fafbfc; cursor: pointer; transition: all 0.3s ease;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
                            <div style="display: flex; align-items: center; gap: 12px; font-weight: 600; color: #2c3e50; font-size: 14px;">
                                <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #ffe5cc 0%, #ffd9b3 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #ff9800; font-size: 20px;">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div><?= h($assignedSites["downtown"]["name"]) ?></div>
                            </div>
                            <div style="background: #d4edda; color: #155724; padding: 5px 13px; border-radius: 5px; font-size: 10px; font-weight: 700;">ACTIVE</div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; font-size: 13px;">
                            <div style="color: #555;">
                                <div style="color: #9ca3af; font-size: 11px; margin-bottom: 5px; text-transform: uppercase; font-weight: 600;">Workers:</div>
                                <div style="font-weight: 700; color: #1f2937; font-size: 16px;"><?= i($assignedSites["downtown"]["workers"]) ?></div>
                            </div>
                            <div style="color: #555;">
                                <div style="color: #9ca3af; font-size: 11px; margin-bottom: 5px; text-transform: uppercase; font-weight: 600;">Today's attendance:</div>
                                <div style="font-weight: 700; color: #1f2937; font-size: 16px;"><?= i($assignedSites["downtown"]["attendance_present"]) ?>/<?= i($assignedSites["downtown"]["attendance_total"]) ?></div>
                            </div>
                        </div>
                        <button style="width: 100%; padding: 11px 16px; background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; transition: all 0.3s ease;" onclick="window.location.href='attendance.php#downtown';">
                            <i class="fas fa-arrow-right" style="margin-right: 8px;"></i>View Attendance Records
                        </button>
                    </div>
                </div>
            </div>

            <!-- Activity & Quick Actions -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                <!-- Activity Section -->
                <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06);">
                    <div style="font-size: 15px; font-weight: 700; color: #2c3e50; margin-bottom: 20px;">Activity Feed</div>
                    <div style="display: flex; gap: 15px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #e5e7eb;">
                        <div style="width: 35px; height: 35px; border-radius: 50%; background: #d4edda; display: flex; align-items: center; justify-content: center; color: #28a745; font-size: 16px; flex-shrink: 0;">
                            <i class="fas fa-check"></i>
                        </div>
                        <div>
                            <div style="font-size: 13px; color: #2c3e50; margin-bottom: 3px; font-weight: 600;">Payroll Processed</div>
                            <div style="font-size: 12px; color: #9ca3af;">Oct 1-15, 2023</div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 15px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #e5e7eb;">
                        <div style="width: 35px; height: 35px; border-radius: 50%; background: #d4edda; display: flex; align-items: center; justify-content: center; color: #28a745; font-size: 16px; flex-shrink: 0;">
                            <i class="fas fa-check"></i>
                        </div>
                        <div>
                            <div style="font-size: 13px; color: #2c3e50; margin-bottom: 3px; font-weight: 600;">Report Generated</div>
                            <div style="font-size: 12px; color: #9ca3af;">Sep 28-Oct 1, 2023</div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.06);">
                    <div style="font-size: 15px; font-weight: 700; color: #2c3e50; margin-bottom: 20px;">Quick Actions</div>
                    <div style="display: grid; grid-template-columns: 1fr; gap: 15px;">
                        <a href="payroll-process.php" style="background: linear-gradient(135deg, #cfe9f3 0%, #b3d9e8 100%); padding: 20px; border-radius: 10px; text-align: center; cursor: pointer; text-decoration: none; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease;">
                            <div style="font-size: 24px; margin-bottom: 8px; color: #0066cc;">
                                <i class="fas fa-file-invoice"></i>
                            </div>
                            <div style="font-weight: 600; font-size: 13px; color: #2c3e50;">Process Payroll</div>
                        </a>
                        <a href="attendance.php" style="background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%); padding: 20px; border-radius: 10px; text-align: center; cursor: pointer; text-decoration: none; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease;">
                            <div style="font-size: 24px; margin-bottom: 8px; color: #28a745;">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <div style="font-weight: 600; font-size: 13px; color: #2c3e50;">View Attendance</div>
                        </a>
                        <a href="report.php" style="background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%); padding: 20px; border-radius: 10px; text-align: center; cursor: pointer; text-decoration: none; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease;">
                            <div style="font-size: 24px; margin-bottom: 8px; color: #dc3545;">
                                <i class="fas fa-file-pdf"></i>
                            </div>
                            <div style="font-weight: 600; font-size: 13px; color: #2c3e50;">Generate Report</div>
                        </a>
                    </div>
                </div>
            </div>
            </div>

            <div id="view-site" class="payroll-view" hidden>
                <div class="site-header-row">
                    <a class="back-link" href="payroll-process.php">
                        <i class="fas fa-arrow-left"></i>
                        Back to Payroll Processing
                    </a>
                    <div class="site-actions">
                        <button class="action-btn info" type="button" id="btn-print-payslips">
                            <i class="fas fa-print"></i>
                            Print/Download All Payslips
                        </button>
                        <button class="action-btn secondary" type="button" id="btn-generate-report">
                            <i class="fas fa-file-csv"></i>
                            Generate Report
                        </button>
                        <button class="action-btn primary" type="button" id="btn-process-payroll">
                            <i class="fas fa-check"></i>
                            Process Payroll
                        </button>
                    </div>
                </div>

                <div class="site-title">
                    <div class="site-name" id="siteName">Site</div>
                    <div class="site-period" id="sitePeriod">Pay period</div>
                </div>

                <div class="site-summary-grid">
                    <div class="summary-card">
                        <div class="summary-icon" style="background: #e8f5e9; color: #2e7d32;">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div>
                            <div class="summary-label">Total Gross</div>
                            <div class="summary-value" id="metricGross">PHP 0.00</div>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-icon" style="background: #fdecea; color: #c62828;">
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div>
                            <div class="summary-label">Total Deductions</div>
                            <div class="summary-value" id="metricDeductions">PHP 0.00</div>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-icon" style="background: #e3f2fd; color: #1565c0;">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div>
                            <div class="summary-label">Total Net Pay</div>
                            <div class="summary-value" id="metricNet">PHP 0.00</div>
                        </div>
                    </div>
                </div>

                <div class="site-table-card">
                    <div class="site-table-title">
                        <div>Workers Assigned</div>
                        <div class="site-table-subtitle" id="siteTableMeta">0 workers</div>
                    </div>
                    <div class="site-table-wrap">
                        <table class="site-payroll-table" aria-label="Site payroll table">
                            <thead>
                                <tr>
                                    <th>Worker</th>
                                    <th>Role</th>
                                    <th class="center">Days</th>
                                    <th class="right">Gross</th>
                                    <th class="right">Deductions</th>
                                    <th class="right">Net</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody id="sitePayrollTbody"></tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3">Totals</td>
                                    <td class="right" id="totalGross">PHP 0.00</td>
                                    <td class="right" id="totalDeductions">PHP 0.00</td>
                                    <td class="right" id="totalNet">PHP 0.00</td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <div id="payrollSuccess" class="success-banner" hidden>
                    <i class="fas fa-check-circle"></i>
                    <div class="msg">Payroll processed successfully! You can now print individual or all payslips.</div>
                    <a href="#" id="successReportLink">View Official Report</a>
                </div>
            </div>
        </div>
    </div>

    <script>window.sitePayrollData = <?= json_encode($sitePayrollData, JSON_UNESCAPED_SLASHES) ?>;</script>
    <script src="assets/js/payroll.js" defer></script>
</body>
</html>



