﻿-- Payroll System DB schema (MySQL / MariaDB)
-- Import this in phpMyAdmin, or run in MySQL CLI.

CREATE DATABASE IF NOT EXISTS payroll_system
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE payroll_system;

CREATE TABLE IF NOT EXISTS sites (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sites_slug (slug)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS workers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  emp_code VARCHAR(32) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(128) NOT NULL,
  site_slug VARCHAR(64) NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'active',
  daily_rate DECIMAL(12,2) NOT NULL DEFAULT 0,
  hired_date DATE NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_workers_emp_code (emp_code),
  KEY idx_workers_site (site_slug),
  CONSTRAINT fk_workers_site FOREIGN KEY (site_slug) REFERENCES sites(slug)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance_records (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  worker_id INT UNSIGNED NOT NULL,
  site_slug VARCHAR(64) NOT NULL,
  work_date DATE NOT NULL,
  status VARCHAR(16) NOT NULL,
  time_in TIME NULL,
  time_out TIME NULL,
  hours_worked DECIMAL(5,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attendance_worker_date (worker_id, work_date),
  KEY idx_attendance_site_date (site_slug, work_date),
  CONSTRAINT fk_attendance_worker FOREIGN KEY (worker_id) REFERENCES workers(id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_attendance_site FOREIGN KEY (site_slug) REFERENCES sites(slug)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payroll_periods (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  site_slug VARCHAR(64) NOT NULL,
  period_label VARCHAR(64) NOT NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'open',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_period_site_label (site_slug, period_label),
  KEY idx_period_site (site_slug),
  CONSTRAINT fk_period_site FOREIGN KEY (site_slug) REFERENCES sites(slug)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payroll_entries (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  period_id INT UNSIGNED NOT NULL,
  worker_id INT UNSIGNED NOT NULL,
  days INT NOT NULL DEFAULT 0,
  gross DECIMAL(12,2) NOT NULL DEFAULT 0,
  deductions DECIMAL(12,2) NOT NULL DEFAULT 0,
  status VARCHAR(16) NOT NULL DEFAULT 'Ready',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_entry_period_worker (period_id, worker_id),
  KEY idx_entry_period (period_id),
  CONSTRAINT fk_entry_period FOREIGN KEY (period_id) REFERENCES payroll_periods(id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_entry_worker FOREIGN KEY (worker_id) REFERENCES workers(id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- Seed minimal data to match your current UI demo
INSERT IGNORE INTO sites (slug, name, status) VALUES
  ('main-street', 'Main Street Project', 'ACTIVE'),
  ('downtown', 'Downtown Office Complex', 'ACTIVE');

INSERT IGNORE INTO payroll_periods (site_slug, period_label, status) VALUES
  ('main-street', 'Oct 1-15, 2023', 'open'),
  ('downtown', 'Oct 1-15, 2023', 'open');

-- Workers (Main Street)
INSERT IGNORE INTO workers (emp_code, full_name, role, site_slug, status, daily_rate, hired_date) VALUES
  ('EMP-MS-001', 'Juan Dela Cruz', 'Foreman', 'main-street', 'active', 0, '2023-01-01'),
  ('EMP-MS-002', 'Mark Santos', 'Carpenter', 'main-street', 'active', 0, '2023-01-01'),
  ('EMP-MS-003', 'Paolo Reyes', 'Mason', 'main-street', 'active', 0, '2023-01-01'),
  ('EMP-MS-004', 'Leo Garcia', 'Laborer', 'main-street', 'active', 0, '2023-01-01'),
  ('EMP-MS-005', 'Ryan Flores', 'Electrician', 'main-street', 'active', 0, '2023-01-01');

-- Workers (Downtown)
INSERT IGNORE INTO workers (emp_code, full_name, role, site_slug, status, daily_rate, hired_date) VALUES
  ('EMP-DT-001', 'Allan Cruz', 'Foreman', 'downtown', 'active', 0, '2023-01-01'),
  ('EMP-DT-002', 'Kevin Lim', 'Carpenter', 'downtown', 'active', 0, '2023-01-01'),
  ('EMP-DT-003', 'Jerome Tan', 'Mason', 'downtown', 'active', 0, '2023-01-01'),
  ('EMP-DT-004', 'Noel Dizon', 'Laborer', 'downtown', 'active', 0, '2023-01-01'),
  ('EMP-DT-005', 'Paolo Uy', 'Plumber', 'downtown', 'active', 0, '2023-01-01');

-- Payroll entries
INSERT IGNORE INTO payroll_entries (period_id, worker_id, days, gross, deductions, status)
SELECT p.id, w.id,
  CASE w.emp_code
    WHEN 'EMP-MS-001' THEN 12
    WHEN 'EMP-MS-002' THEN 11
    WHEN 'EMP-MS-003' THEN 12
    WHEN 'EMP-MS-004' THEN 10
    WHEN 'EMP-MS-005' THEN 12
    WHEN 'EMP-DT-001' THEN 12
    WHEN 'EMP-DT-002' THEN 11
    WHEN 'EMP-DT-003' THEN 10
    WHEN 'EMP-DT-004' THEN 12
    WHEN 'EMP-DT-005' THEN 11
    ELSE 0
  END AS days,
  CASE w.emp_code
    WHEN 'EMP-MS-001' THEN 9800
    WHEN 'EMP-MS-002' THEN 7700
    WHEN 'EMP-MS-003' THEN 8200
    WHEN 'EMP-MS-004' THEN 6100
    WHEN 'EMP-MS-005' THEN 9500
    WHEN 'EMP-DT-001' THEN 9200
    WHEN 'EMP-DT-002' THEN 7400
    WHEN 'EMP-DT-003' THEN 6600
    WHEN 'EMP-DT-004' THEN 7100
    WHEN 'EMP-DT-005' THEN 6900
    ELSE 0
  END AS gross,
  CASE w.emp_code
    WHEN 'EMP-MS-001' THEN 1200
    WHEN 'EMP-MS-002' THEN 900
    WHEN 'EMP-MS-003' THEN 1000
    WHEN 'EMP-MS-004' THEN 700
    WHEN 'EMP-MS-005' THEN 1100
    WHEN 'EMP-DT-001' THEN 900
    WHEN 'EMP-DT-002' THEN 800
    WHEN 'EMP-DT-003' THEN 700
    WHEN 'EMP-DT-004' THEN 750
    WHEN 'EMP-DT-005' THEN 650
    ELSE 0
  END AS deductions,
  'Ready'
FROM workers w
JOIN payroll_periods p ON p.site_slug = w.site_slug AND p.period_label = 'Oct 1-15, 2023';

