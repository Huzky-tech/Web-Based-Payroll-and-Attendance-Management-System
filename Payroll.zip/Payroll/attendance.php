<?php
declare(strict_types=1);

require __DIR__ . '/lib/render.php';

$payload = null;
try {
    require_once __DIR__ . '/lib/repo.php';
    $pdo = db();
    $payload = repo_attendance_ui_data($pdo);
} catch (Throwable $e) {
    $payload = null;
}

$head = '';
if (is_array($payload)) {
    $jSites = json_encode($payload['sites'] ?? null, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $jRecords = json_encode($payload['records'] ?? null, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    if ($jSites !== false && $jRecords !== false) {
        $head = "<script>" .
            "window.attendanceSites = " . $jSites . ";" .
            "window.attendanceRecords = " . $jRecords . ";" .
            "</script>";
    }
}

render_html_with_php_links(__DIR__ . '/attendance.html', [
    'head_inject' => $head,
]);