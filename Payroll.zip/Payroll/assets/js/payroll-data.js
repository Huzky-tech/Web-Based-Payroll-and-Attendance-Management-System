(function () {
  "use strict";

  // Shared demo payroll data used by payroll + report pages.
  // If PHP injected `window.sitePayrollData` (from SQL), do not overwrite it.
  if (window.sitePayrollData && typeof window.sitePayrollData === "object") return;

  window.sitePayrollData = {
    "main-street": {
      name: "Main Street Project",
      period: "Oct 1-15, 2023",
      workers: [
        { name: "Juan Dela Cruz", role: "Foreman", days: 12, gross: 9800, deductions: 1200, status: "Ready" },
        { name: "Mark Santos", role: "Carpenter", days: 11, gross: 7700, deductions: 900, status: "Ready" },
        { name: "Paolo Reyes", role: "Mason", days: 12, gross: 8200, deductions: 1000, status: "Ready" },
        { name: "Leo Garcia", role: "Laborer", days: 10, gross: 6100, deductions: 700, status: "Ready" },
        { name: "Ryan Flores", role: "Electrician", days: 12, gross: 9500, deductions: 1100, status: "Ready" }
      ]
    },
    downtown: {
      name: "Downtown Office Complex",
      period: "Oct 1-15, 2023",
      workers: [
        { name: "Allan Cruz", role: "Foreman", days: 12, gross: 9200, deductions: 900, status: "Ready" },
        { name: "Kevin Lim", role: "Carpenter", days: 11, gross: 7400, deductions: 800, status: "Ready" },
        { name: "Jerome Tan", role: "Mason", days: 10, gross: 6600, deductions: 700, status: "Ready" },
        { name: "Noel Dizon", role: "Laborer", days: 12, gross: 7100, deductions: 750, status: "Ready" },
        { name: "Paolo Uy", role: "Plumber", days: 11, gross: 6900, deductions: 650, status: "Ready" }
      ]
    }
  };
})();