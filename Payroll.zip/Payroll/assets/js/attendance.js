(function () {
  "use strict";

        const statusMeta = {
            present: { label: "Present", color: "#22c55e", badge: "status-present", icon: "fa-check" },
            late: { label: "Late", color: "#f59e0b", badge: "status-late", icon: "fa-clock" },
            absent: { label: "Absent", color: "#ef4444", badge: "status-absent", icon: "fa-times" },
            early: { label: "Early Out", color: "#f97316", badge: "status-late", icon: "fa-person-walking-arrow-right" },
            leave: { label: "On Leave", color: "#3b82f6", badge: "status-leave", icon: "fa-calendar" }
        };

        // Keep these IDs compatible with existing links like `attendance.html#main-street`.
        const defaultSites = [
            { id: "main-street", name: "Main Street Project", icon: "fa-building" },
            { id: "downtown", name: "Downtown Office Complex", icon: "fa-building" },
            { id: "park-avenue", name: "Park Avenue Mall", icon: "fa-city" },
            { id: "highway", name: "Highway Expansion", icon: "fa-road" },
            { id: "harbor", name: "Harbor View Development", icon: "fa-water" },
            { id: "bridge", name: "Bridge Project Alpha", icon: "fa-bridge" }
        ];

        // Demo logs; replace with real records later.
        const defaultRecords = [
            // Main Street Project
            { siteId: "main-street", name: "John Dela Cruz", empId: "EMP-001", status: "present", timeIn: "08:00 AM", timeOut: "05:00 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "JD", avatarBg: "linear-gradient(135deg, #3b82f6, #1e40af)" },
            { siteId: "main-street", name: "Maria Jose", empId: "EMP-003", status: "late", timeIn: "08:30 AM", timeOut: "05:15 PM", hours: "8.75 hrs", date: "Jan 15, 2024", avatar: "MJ", avatarBg: "linear-gradient(135deg, #a855f7, #7e22ce)" },
            { siteId: "main-street", name: "David Martinez", empId: "EMP-007", status: "present", timeIn: "07:55 AM", timeOut: "04:55 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "DM", avatarBg: "linear-gradient(135deg, #8b5cf6, #6d28d9)" },
            { siteId: "main-street", name: "Lisa Davis", empId: "EMP-009", status: "present", timeIn: "08:00 AM", timeOut: "05:00 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "LD", avatarBg: "linear-gradient(135deg, #0ea5e9, #0284c7)" },
            { siteId: "main-street", name: "Angela Brown", empId: "EMP-011", status: "leave", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "AB", avatarBg: "linear-gradient(135deg, #f59e0b, #d97706)" },

            // Downtown Office Complex
            { siteId: "downtown", name: "Jane Santos", empId: "EMP-002", status: "absent", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "JS", avatarBg: "linear-gradient(135deg, #f97316, #c2410c)" },
            { siteId: "downtown", name: "Maria Garcia", empId: "EMP-004", status: "present", timeIn: "08:00 AM", timeOut: "05:00 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "MG", avatarBg: "linear-gradient(135deg, #06b6d4, #0891b2)" },
            { siteId: "downtown", name: "Sarah Wilson", empId: "EMP-006", status: "present", timeIn: "08:05 AM", timeOut: "05:10 PM", hours: "8.92 hrs", date: "Jan 15, 2024", avatar: "SW", avatarBg: "linear-gradient(135deg, #14b8a6, #0d9488)" },
            { siteId: "downtown", name: "Robert Pena", empId: "EMP-008", status: "late", timeIn: "08:15 AM", timeOut: "05:00 PM", hours: "8.75 hrs", date: "Jan 15, 2024", avatar: "RP", avatarBg: "linear-gradient(135deg, #f43f5e, #be185d)" },
            { siteId: "downtown", name: "Michael Chen", empId: "EMP-010", status: "present", timeIn: "08:02 AM", timeOut: "05:05 PM", hours: "8.95 hrs", date: "Jan 15, 2024", avatar: "MC", avatarBg: "linear-gradient(135deg, #10b981, #059669)" },
            { siteId: "downtown", name: "Carlos Rodriguez", empId: "EMP-005", status: "leave", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "CR", avatarBg: "linear-gradient(135deg, #ec4899, #be185d)" },

            // Extra demo sites (to match the card layout in your screenshot)
            { siteId: "park-avenue", name: "Noah Reed", empId: "EMP-012", status: "present", timeIn: "08:01 AM", timeOut: "05:00 PM", hours: "8.98 hrs", date: "Jan 15, 2024", avatar: "NR", avatarBg: "linear-gradient(135deg, #3b82f6, #1e40af)" },
            { siteId: "park-avenue", name: "Olivia Stone", empId: "EMP-013", status: "present", timeIn: "08:00 AM", timeOut: "05:10 PM", hours: "9.17 hrs", date: "Jan 15, 2024", avatar: "OS", avatarBg: "linear-gradient(135deg, #14b8a6, #0d9488)" },
            { siteId: "park-avenue", name: "Ethan Ray", empId: "EMP-014", status: "late", timeIn: "08:20 AM", timeOut: "05:00 PM", hours: "8.67 hrs", date: "Jan 15, 2024", avatar: "ER", avatarBg: "linear-gradient(135deg, #f59e0b, #d97706)" },
            { siteId: "park-avenue", name: "Ava Cole", empId: "EMP-015", status: "absent", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "AC", avatarBg: "linear-gradient(135deg, #f43f5e, #be185d)" },
            { siteId: "park-avenue", name: "Liam Park", empId: "EMP-016", status: "early", timeIn: "08:00 AM", timeOut: "03:30 PM", hours: "7.5 hrs", date: "Jan 15, 2024", avatar: "LP", avatarBg: "linear-gradient(135deg, #06b6d4, #0891b2)" },

            { siteId: "highway", name: "Mia Brooks", empId: "EMP-017", status: "present", timeIn: "08:00 AM", timeOut: "05:00 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "MB", avatarBg: "linear-gradient(135deg, #8b5cf6, #6d28d9)" },
            { siteId: "highway", name: "James King", empId: "EMP-018", status: "absent", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "JK", avatarBg: "linear-gradient(135deg, #ef4444, #b91c1c)" },

            { siteId: "harbor", name: "Sophia Lin", empId: "EMP-019", status: "present", timeIn: "08:05 AM", timeOut: "05:00 PM", hours: "8.92 hrs", date: "Jan 15, 2024", avatar: "SL", avatarBg: "linear-gradient(135deg, #10b981, #059669)" },
            { siteId: "harbor", name: "Henry Cruz", empId: "EMP-020", status: "early", timeIn: "08:00 AM", timeOut: "04:00 PM", hours: "8.0 hrs", date: "Jan 15, 2024", avatar: "HC", avatarBg: "linear-gradient(135deg, #f97316, #c2410c)" },
            { siteId: "harbor", name: "Chloe Tan", empId: "EMP-021", status: "leave", timeIn: "-", timeOut: "-", hours: "0.0 hrs", date: "Jan 15, 2024", avatar: "CT", avatarBg: "linear-gradient(135deg, #3b82f6, #1e40af)" },

            { siteId: "bridge", name: "Daniel Wu", empId: "EMP-022", status: "present", timeIn: "08:00 AM", timeOut: "05:00 PM", hours: "9.0 hrs", date: "Jan 15, 2024", avatar: "DW", avatarBg: "linear-gradient(135deg, #06b6d4, #0891b2)" }
        ];
        // Use server-injected data (SQL) when available; otherwise fall back to demo data.
        const sites = Array.isArray(window.attendanceSites) && window.attendanceSites.length ? window.attendanceSites : defaultSites;
        const records = Array.isArray(window.attendanceRecords) && window.attendanceRecords.length ? window.attendanceRecords : defaultRecords;

        let activeSiteId = "all";
        let activeStatusFilter = "all";

        function byId(id) { return document.getElementById(id); }
        function esc(text) {
            return String(text)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/\"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        function getSiteName(siteId) {
            const site = sites.find(s => s.id === siteId);
            return site ? site.name : "All Sites";
        }

        function countsFor(siteId) {
            const list = siteId === "all" ? records : records.filter(r => r.siteId === siteId);
            const total = list.length;
            const present = list.filter(r => r.status === "present").length;
            const late = list.filter(r => r.status === "late").length;
            const absent = list.filter(r => r.status === "absent").length;
            const early = list.filter(r => r.status === "early").length;
            return { total, present, late, absent, early };
        }

        function miniRow(key, value, pct) {
            const meta = statusMeta[key];
            const color = meta ? meta.color : "#9ca3af";
            const label = meta ? meta.label : key;
            const clamped = Math.max(0, Math.min(100, Number(pct) || 0));
            return `
                <div class="mini-row">
                    <div class="mini-left">
                        <span class="dot" style="background:${color};"></span>
                        <span class="mini-label">${esc(label)}</span>
                    </div>
                    <div class="mini-right">
                        <div class="mini-bar"><div class="mini-fill" style="background:${color};width:${clamped}%;"></div></div>
                        <div class="mini-value">${Number(value) || 0}</div>
                    </div>
                </div>
            `;
        }

        function renderSiteFilterSelect() {
            const sel = byId("siteFilterSelect");
            const options = [{ id: "all", name: "All Sites" }, ...sites.map(s => ({ id: s.id, name: s.name }))];
            sel.innerHTML = options.map(o => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join("");
            sel.value = activeSiteId;
        }

        function renderSiteCards() {
            const q = String(byId("siteSearchInput").value || "").trim().toLowerCase();
            const host = byId("siteCards");
            host.innerHTML = "";

            const cards = [{ id: "all", name: "All Sites", icon: "fa-layer-group" }, ...sites];
            for (const site of cards) {
                if (q && !String(site.name).toLowerCase().includes(q)) continue;
                const c = countsFor(site.id);
                const total = Math.max(1, c.total);

                const card = document.createElement("div");
                card.className = "site-overview-card" + (activeSiteId === site.id ? " active" : "");
                card.tabIndex = 0;
                card.setAttribute("role", "button");
                card.addEventListener("click", () => setActiveSite(site.id));
                card.addEventListener("keydown", (ev) => {
                    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); setActiveSite(site.id); }
                });

                const presentPct = Math.round((c.present / total) * 100);
                const latePct = Math.round((c.late / total) * 100);
                const absentPct = Math.round((c.absent / total) * 100);
                const earlyPct = Math.round((c.early / total) * 100);

                card.innerHTML = `
                    <div class="site-card-top">
                        <div class="site-icon"><i class="fas ${esc(site.icon || "fa-building")}"></i></div>
                        <div style="flex:1;min-width:0;">
                            <div class="site-card-name">${esc(site.name)}</div>
                        </div>
                    </div>
                    <div class="site-count">${c.total}</div>
                    <div class="mini-list">
                        ${miniRow("present", c.present, presentPct)}
                        ${miniRow("late", c.late, latePct)}
                        ${miniRow("absent", c.absent, absentPct)}
                        ${miniRow("early", c.early, earlyPct)}
                    </div>
                `;
                host.appendChild(card);
            }
        }

        function renderRow(r) {
            const meta = statusMeta[r.status] || statusMeta.present;
            const badgeClass = meta.badge || "status-present";
            const statusLabel = meta.label || "Present";
            const iconClass = meta.icon || "fa-check";

            return `
                <tr>
                    <td>
                        <div class="employee-cell">
                            <div class="employee-avatar" style="background:${esc(r.avatarBg || "#111827")};">${esc(r.avatar || "")}</div>
                            <div class="employee-info">
                                <strong>${esc(r.name || "")}</strong>
                                <span>ID: ${esc(r.empId || "")}</span>
                            </div>
                        </div>
                    </td>
                    <td>${esc(r.timeIn || "-")}</td>
                    <td>${esc(r.timeOut || "-")}</td>
                    <td>${esc(r.hours || "-")}</td>
                    <td><span class="status-badge ${esc(badgeClass)}"><i class="fas ${esc(iconClass)}"></i>${esc(statusLabel)}</span></td>
                    <td>${esc(r.date || "-")}</td>
                    <td>
                        <span class="row-actions">
                            <button class="icon-btn" type="button" title="View" onclick="alert('View attendance: ${esc(r.name || "")} (demo).')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </span>
                    </td>
                </tr>
            `;
        }

        function renderSections() {
            const host = byId("siteSections");
            host.innerHTML = "";

            const q = String(byId("siteSearchInput").value || "").trim().toLowerCase();
            const listSites = activeSiteId === "all" ? sites : sites.filter(s => s.id === activeSiteId);

            for (const site of listSites) {
                if (q && !String(site.name).toLowerCase().includes(q)) continue;
                let siteRecords = records.filter(r => r.siteId === site.id);
                if (activeStatusFilter !== "all") {
                    siteRecords = siteRecords.filter(r => r.status === activeStatusFilter);
                }

                const section = document.createElement("div");
                section.className = "table-container";
                section.innerHTML = `
                    <div class="section-headline">
                        <div>
                            <div class="section-name">${esc(site.name)}</div>
                            <div class="section-meta">${siteRecords.length} logs</div>
                        </div>
                    </div>
                    <table class="employees-table" aria-label="Attendance table">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Hours Worked</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${siteRecords.map(renderRow).join("") || `<tr><td colspan="7" style="padding:18px;color:#9ca3af;font-weight:800;">No records</td></tr>`}
                        </tbody>
                    </table>
                `;
                host.appendChild(section);
            }
        }

        function setActiveSite(siteId) {
            activeSiteId = siteId;
            byId("siteFilterSelect").value = siteId;
            byId("pageSubtitle").textContent = siteId === "all" ? "Attendance Tracking" : ("Attendance Tracking - " + getSiteName(siteId));

            if (siteId === "all") {
                history.replaceState(null, "", window.location.pathname);
            } else {
                window.location.hash = siteId;
            }

            renderSiteCards();
            renderSections();
        }

        function initFromHash() {
            const hash = (window.location.hash || "").replace("#", "");
            if (!hash) return "all";
            return sites.some(s => s.id === hash) ? hash : "all";
        }

        document.addEventListener("DOMContentLoaded", () => {
            activeSiteId = initFromHash();
            renderSiteFilterSelect();
            byId("siteFilterSelect").value = activeSiteId;
            activeStatusFilter = String(byId("statusFilterSelect").value || "all");

            byId("siteSearchInput").addEventListener("input", () => { renderSiteCards(); renderSections(); });
            byId("siteFilterSelect").addEventListener("change", (ev) => setActiveSite(ev.target.value));
            byId("statusFilterSelect").addEventListener("change", (ev) => {
                activeStatusFilter = String(ev.target.value || "all");
                renderSections();
            });
            byId("btnExport").addEventListener("click", () => alert("Export (demo UI)."));

            window.addEventListener("hashchange", () => {
                const desired = initFromHash();
                if (desired !== activeSiteId) setActiveSite(desired);
            });

            setActiveSite(activeSiteId);
        });

})();
