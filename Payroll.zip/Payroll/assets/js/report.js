﻿(function () {
  "use strict";

  const sitePayrollData = window.sitePayrollData || {};
  const money = new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  function byId(id) {
    return document.getElementById(id);
  }

  function esc(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatMoney(n) {
    return money.format(Number(n) || 0);
  }

  function getSiteIdFromHash() {
    const hash = (window.location.hash || "").replace("#", "").toLowerCase();
    if (!hash) return "main-street";
    return sitePayrollData[hash] ? hash : "main-street";
  }

  function render(siteId) {
    const data = sitePayrollData[siteId];
    if (!data) return;

    const subtitle = byId("pageSubtitle");
    const title = byId("reportTitle");
    const meta = byId("reportMeta");

    if (subtitle) subtitle.textContent = "Payroll Period: " + data.period + " | " + data.name;
    if (title) title.textContent = "PAYROLL REPORT - " + String(data.name).toUpperCase();
    if (meta) meta.textContent = "Payroll Period: " + data.period;

    const tbody = byId("reportTbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    let grossTotal = 0;
    let dedTotal = 0;
    let netTotal = 0;

    for (const w of data.workers || []) {
      const gross = Number(w.gross) || 0;
      const ded = Number(w.deductions) || 0;
      const net = Math.max(0, gross - ded);
      grossTotal += gross;
      dedTotal += ded;
      netTotal += net;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-weight:900;color:#111827;">${esc(w.name || "")}</td>
        <td>${esc(w.role || "")}</td>
        <td class="center" style="font-weight:900;">${Number(w.days) || 0}</td>
        <td class="right" style="font-weight:900;">${esc(formatMoney(gross))}</td>
        <td class="right" style="font-weight:900;color:#b91c1c;">${esc(formatMoney(ded))}</td>
        <td class="right" style="font-weight:900;color:#166534;">${esc(formatMoney(net))}</td>
      `;
      tbody.appendChild(tr);
    }

    const tGross = byId("tGross");
    const tDed = byId("tDed");
    const tNet = byId("tNet");
    if (tGross) tGross.textContent = formatMoney(grossTotal);
    if (tDed) tDed.textContent = formatMoney(dedTotal);
    if (tNet) tNet.textContent = formatMoney(netTotal);
  }

  function downloadCsv(siteId) {
    const data = sitePayrollData[siteId];
    if (!data) return;

    let csv = "PAYROLL REPORT - " + data.name + "\n";
    csv += "Philippians CDO\n";
    csv += "Payroll Period: " + data.period + "\n\n";
    csv += "Worker,Role,Days,Gross,Deductions,Net\n";

    for (const w of data.workers || []) {
      const gross = Number(w.gross) || 0;
      const ded = Number(w.deductions) || 0;
      const net = Math.max(0, gross - ded);
      const safeName = String(w.name || "").replace(/\"/g, '""');
      const safeRole = String(w.role || "").replace(/\"/g, '""');
      csv += `"${safeName}","${safeRole}",${Number(w.days) || 0},${gross},${ded},${net}\n`;
    }

    const element = document.createElement("a");
    element.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csv));
    element.setAttribute("download", "payroll_report_" + siteId + ".csv");
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }

  document.addEventListener("DOMContentLoaded", () => {
    let siteId = getSiteIdFromHash();
    render(siteId);

    const btnPrint = byId("btnPrint");
    const btnDownload = byId("btnDownload");

    if (btnPrint) btnPrint.addEventListener("click", () => window.print());
    if (btnDownload) btnDownload.addEventListener("click", () => downloadCsv(siteId));

    window.addEventListener("hashchange", () => {
      siteId = getSiteIdFromHash();
      render(siteId);
    });
  });
})();
