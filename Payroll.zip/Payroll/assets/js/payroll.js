﻿(function () {
  "use strict";

  function page(name) {
    const isPhp = (location.pathname || "").toLowerCase().endsWith(".php");
    return name + (isPhp ? ".php" : ".html");
  }

  const sitePayrollData = window.sitePayrollData || {};

  const money = new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  let activeSiteId = null;

  function formatMoney(amount) {
    const value = Number(amount) || 0;
    return money.format(value);
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function hideSuccessBanner() {
    const banner = byId("payrollSuccess");
    if (banner) banner.hidden = true;

    const link = byId("successReportLink");
    if (link && activeSiteId) link.href = page("report") + "#" + activeSiteId;
  }

  function showDashboard() {
    const vDash = byId("view-dashboard");
    const vSite = byId("view-site");
    if (vDash) vDash.hidden = false;
    if (vSite) vSite.hidden = true;
    activeSiteId = null;

    hideSuccessBanner();

    const titleEl = document.querySelector(".page-title");
    const subtitleEl = document.querySelector(".page-subtitle");
    if (titleEl) titleEl.textContent = "Payroll";
    if (subtitleEl) subtitleEl.textContent = "Manage pay process and project payroll";
  }

  function renderSite(siteId) {
    const data = sitePayrollData[siteId];
    if (!data) return false;

    activeSiteId = siteId;

    const workers = Array.isArray(data.workers) ? data.workers : [];
    let totalGross = 0;
    let totalDeductions = 0;
    let totalNet = 0;

    const tbody = byId("sitePayrollTbody");
    if (!tbody) return false;
    tbody.innerHTML = "";

    for (const worker of workers) {
      const gross = Number(worker.gross) || 0;
      const deductions = Number(worker.deductions) || 0;
      const net = Math.max(0, gross - deductions);

      totalGross += gross;
      totalDeductions += deductions;
      totalNet += net;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-weight: 800; color: #1f2937;">${escapeHtml(worker.name || "")}</td>
        <td>${escapeHtml(worker.role || "")}</td>
        <td class="center" style="font-weight: 800;">${Number(worker.days) || 0}</td>
        <td class="right" style="font-weight: 900;">${formatMoney(gross)}</td>
        <td class="right" style="font-weight: 900; color: #b91c1c;">${formatMoney(deductions)}</td>
        <td class="right" style="font-weight: 900; color: #166534;">${formatMoney(net)}</td>
        <td><span class="pill"><i class="fas fa-check-circle" style="color:#16a34a;"></i>${escapeHtml(worker.status || "Ready")}</span></td>
      `;
      tbody.appendChild(tr);
    }

    const nameEl = byId("siteName");
    const periodEl = byId("sitePeriod");
    if (nameEl) nameEl.textContent = data.name;
    if (periodEl) periodEl.textContent = data.period;

    const metricGrossEl = byId("metricGross");
    const metricDeductionsEl = byId("metricDeductions");
    const metricNetEl = byId("metricNet");
    if (metricGrossEl) metricGrossEl.textContent = formatMoney(totalGross);
    if (metricDeductionsEl) metricDeductionsEl.textContent = formatMoney(totalDeductions);
    if (metricNetEl) metricNetEl.textContent = formatMoney(totalNet);

    const totalGrossEl = byId("totalGross");
    const totalDeductionsEl = byId("totalDeductions");
    const totalNetEl = byId("totalNet");
    if (totalGrossEl) totalGrossEl.textContent = formatMoney(totalGross);
    if (totalDeductionsEl) totalDeductionsEl.textContent = formatMoney(totalDeductions);
    if (totalNetEl) totalNetEl.textContent = formatMoney(totalNet);

    const tableMetaEl = byId("siteTableMeta");
    if (tableMetaEl) tableMetaEl.textContent = workers.length + " workers";

    const titleEl = document.querySelector(".page-title");
    const subtitleEl = document.querySelector(".page-subtitle");
    if (titleEl) titleEl.textContent = "Payroll";
    if (subtitleEl) subtitleEl.textContent = data.name;

    const vDash = byId("view-dashboard");
    const vSite = byId("view-site");
    if (vDash) vDash.hidden = true;
    if (vSite) vSite.hidden = false;

    // Option 3: never show success banner.
    hideSuccessBanner();

    return true;
  }

  function downloadPayslipsCsv(siteId) {
    const data = sitePayrollData[siteId];
    if (!data) return;

    let csv = "PAYROLL REPORT - " + data.name + "\n";
    csv += "Philippians CDO\n";
    csv += "Payroll Period: " + data.period + "\n\n";
    csv += "Worker,Role,Days,Gross,Deductions,Net\n";

    for (const w of data.workers || []) {
      const gross = Number(w.gross) || 0;
      const deductions = Number(w.deductions) || 0;
      const net = Math.max(0, gross - deductions);
      const safeName = String(w.name || "").replace(/\"/g, '""');
      const safeRole = String(w.role || "").replace(/\"/g, '""');
      csv += `"${safeName}","${safeRole}",${Number(w.days) || 0},${gross},${deductions},${net}\n`;
    }

    const element = document.createElement("a");
    element.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csv));
    element.setAttribute("download", "payslips_" + siteId + ".csv");
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }

  function route() {
    const hash = window.location.hash || "";
    const match = hash.match(/^#payroll-([a-z0-9-]+)$/i);
    if (!match) {
      showDashboard();
      return;
    }

    const siteId = match[1].toLowerCase();
    if (!renderSite(siteId)) showDashboard();
  }

  window.addEventListener("hashchange", route);

  document.addEventListener("DOMContentLoaded", () => {
    const processBtn = byId("btn-process-payroll");
    if (processBtn) {
      processBtn.addEventListener("click", () => {
        // Option 3: never show success banner.
        hideSuccessBanner();
      });
    }

    const reportBtn = byId("btn-generate-report");
    if (reportBtn) {
      reportBtn.addEventListener("click", () => {
        if (!activeSiteId) return;
        window.location.href = page("report") + "#" + activeSiteId;
      });
    }

    const printBtn = byId("btn-print-payslips");
    if (printBtn) {
      printBtn.addEventListener("click", () => {
        if (!activeSiteId) return;
        window.print();
      });

      printBtn.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        if (!activeSiteId) return;
        downloadPayslipsCsv(activeSiteId);
      });
    }

    hideSuccessBanner();
    route();
  });
})();
