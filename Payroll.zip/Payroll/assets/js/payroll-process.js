﻿// Navigate to payroll page with the correct hash
function page(name) {
  const isPhp = (location.pathname || "").toLowerCase().endsWith(".php");
  return name + (isPhp ? ".php" : ".html");
}

function processPayroll(siteId) {
  // Do not mark as processed here.
  // The success banner should appear only after clicking "Process Payroll" on the payroll page.
  window.location.href = page("payroll") + "#payroll-" + siteId;
}
