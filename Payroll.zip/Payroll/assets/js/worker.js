function page(name) {
  const isPhp = (location.pathname || "").toLowerCase().endsWith(".php");
  return name + (isPhp ? ".php" : ".html");
}
        const money = new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP", minimumFractionDigits: 0, maximumFractionDigits: 0 });

        // Demo records; update to match your real employees.
        const defaultEmployees = [
            { id: "E-0001", name: "John Doe", position: "Construction Worker", site: "Main Street Project", status: "active", dailyRate: 15000, date: "2023-05-15" },
            { id: "E-0002", name: "Jane Smith", position: "Electrician", site: "Main Street Project", status: "active", dailyRate: 15000, date: "2023-11-03" },
            { id: "E-0003", name: "Michael Johnson", position: "Plumber", site: "Main Street Project", status: "inactive", dailyRate: 12000, date: "2022-02-24" },
            { id: "E-0004", name: "Jane Williams", position: "Carpenter", site: "Main Street Project", status: "active", dailyRate: 15000, date: "2023-07-18" },
            { id: "E-0005", name: "Albert Santos", position: "Construction Worker", site: "Main Street Project", status: "active", dailyRate: 15000, date: "2023-09-06" },
            { id: "E-0006", name: "Robert Brown", position: "Construction Worker", site: "Downtown Office Complex", status: "onleave", dailyRate: 15000, date: "2024-01-12" },
            { id: "E-0007", name: "Maria Garcia", position: "Electrician", site: "Downtown Office Complex", status: "active", dailyRate: 15000, date: "2023-06-29" }
        ];

        const defaultSites = [
            { key: "Main Street Project", subtitle: "Assigned workers" },
            { key: "Downtown Office Complex", subtitle: "Assigned workers" }
        ];

        const defaultSiteToPayrollHash = {
            "Main Street Project": "main-street",
            "Downtown Office Complex": "downtown"
        };
        // Use server-injected data (SQL) when available; otherwise fall back to demo data.
        const employees = Array.isArray(window.workerEmployees) && window.workerEmployees.length ? window.workerEmployees : defaultEmployees;
        const sites = Array.isArray(window.workerSites) && window.workerSites.length ? window.workerSites : defaultSites;
        const siteToPayrollHash = (window.workerSiteToPayrollHash && typeof window.workerSiteToPayrollHash === "object") ? window.workerSiteToPayrollHash : defaultSiteToPayrollHash;let activeSiteFilter = "all";
        let currentEmployeeId = null;

        function byId(id) { return document.getElementById(id); }
        function esc(text) { return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/'/g, "&#039;"); }
        function initials(name) { const p = String(name || "").trim().split(/\s+/).filter(Boolean); const a = p[0] ? p[0][0] : "U"; const b = p.length > 1 ? p[p.length - 1][0] : ""; return (a + b).toUpperCase(); }
        function labelStatus(s) { if (s === "active") return "Active"; if (s === "inactive") return "Inactive"; if (s === "onleave") return "On Leave"; return "Unknown"; }

        function filteredEmployees() {
            const q = String(byId("searchInput").value || "").trim().toLowerCase();
            const status = String(byId("statusFilter").value || "all");

            return employees.filter(e => {
                if (activeSiteFilter !== "all" && e.site !== activeSiteFilter) return false;
                if (status !== "all" && e.status !== status) return false;
                if (!q) return true;
                const hay = (e.name + " " + e.id + " " + e.position + " " + e.site).toLowerCase();
                return hay.includes(q);
            });
        }

        function renderSiteCards() {
            const host = byId("siteCards");
            host.innerHTML = "";

            for (const site of sites) {
                const count = employees.filter(e => e.site === site.key).length;
                const activeCount = employees.filter(e => e.site === site.key && e.status === "active").length;
                const onLeaveCount = employees.filter(e => e.site === site.key && e.status === "onleave").length;
                const inactiveCount = employees.filter(e => e.site === site.key && e.status === "inactive").length;
                const isFiltered = activeSiteFilter === site.key;

                const card = document.createElement("div");
                card.className = "site-card";
                card.tabIndex = 0;
                card.setAttribute("role", "button");
                card.addEventListener("click", () => { activeSiteFilter = site.key; renderTable(); });
                card.addEventListener("keydown", (ev) => {
                    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); activeSiteFilter = site.key; renderTable(); }
                });

                card.innerHTML = `
                    <div class="site-card-inner">
                        <div class="site-top">
                            <div>
                                <div class="site-name">${esc(site.key)}</div>
                                <div class="site-meta">${esc(site.subtitle)}</div>
                            </div>
                            <div class="site-badge"><span class="dot"></span>Active</div>
                        </div>
                        <div class="site-count">${count}</div>
                        <div class="site-stats">
                            <div class="stat">
                                <div class="stat-label">Active</div>
                                <div class="stat-value active">${activeCount}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">On Leave</div>
                                <div class="stat-value onleave">${onLeaveCount}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Inactive</div>
                                <div class="stat-value inactive">${inactiveCount}</div>
                            </div>
                        </div>
                        <div class="site-bottom">
                            <div class="site-view">View Details <i class="fas fa-arrow-right"></i></div>
                            ${isFiltered ? `<div class="filtered-pill">Filtered</div>` : `<div style="height:22px;"></div>`}
                        </div>
                    </div>
                `;

                host.appendChild(card);
            }
        }

        function renderSelectedBanner() {
            const banner = byId("selectedBanner");
            if (activeSiteFilter === "all") {
                banner.hidden = true;
                return;
            }

            banner.hidden = false;
            byId("selectedSiteName").textContent = activeSiteFilter;

            const hash = siteToPayrollHash[activeSiteFilter];
            const btn = byId("btnPayDetails");
            btn.disabled = !hash;
            btn.style.opacity = hash ? "1" : "0.6";
        }

        function renderTable() {
            renderSiteCards();
            renderSelectedBanner();
            const list = filteredEmployees();
            byId("tableMeta").textContent = list.length + " employees" + (activeSiteFilter !== "all" ? " | " + activeSiteFilter : "");

            const tbody = byId("employeeTbody");
            tbody.innerHTML = "";

            for (const e of list) {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>
                        <div class="employee">
                            <div class="avatar">${esc(initials(e.name))}</div>
                            <div>
                                <div class="emp-name">${esc(e.name)}</div>
                                <div class="emp-id">${esc(e.id)}</div>
                            </div>
                        </div>
                    </td>
                    <td style="font-weight:800;">${esc(e.position)}</td>
                    <td style="font-weight:800;">${esc(e.site)}</td>
                    <td><span class="status ${esc(e.status)}">${esc(labelStatus(e.status))}</span></td>
                    <td class="money">${esc(money.format(e.dailyRate))}</td>
                    <td style="font-weight:800;color:#64748b;white-space:nowrap;">${esc(e.date)}</td>
                    <td>
                        <div class="actions">
                            <a class="cash" title="Update salary" onclick="openModal('${esc(e.id)}')"><i class="fas fa-dollar-sign"></i></a>
                        </div>
                    </td>
                `;
                tbody.appendChild(tr);
            }
        }

        function openModal(employeeId) {
            const modal = byId("salaryModal");
            const employee = employees.find(e => e.id === employeeId);
            if (!employee) return;

            currentEmployeeId = employeeId;
            byId("empName").value = employee.name;
            byId("empPosition").value = employee.position;
            byId("currentSalary").value = money.format(employee.dailyRate);
            byId("newSalary").value = employee.dailyRate;
            byId("notes").value = "";

            modal.classList.add("show");
            modal.setAttribute("aria-hidden", "false");
            byId("newSalary").focus();
        }

        function closeModal() {
            const modal = byId("salaryModal");
            modal.classList.remove("show");
            modal.setAttribute("aria-hidden", "true");
            currentEmployeeId = null;
        }

        window.onclick = function(event) {
            const modal = byId("salaryModal");
            if (event.target === modal) closeModal();
        };

        byId("salaryForm").addEventListener("submit", function(ev) {
            ev.preventDefault();
            const newSalary = Number(byId("newSalary").value);
            if (!Number.isFinite(newSalary) || newSalary < 0) { alert("Please enter a valid salary amount."); return; }

            const employee = employees.find(emp => emp.id === currentEmployeeId);
            if (employee) employee.dailyRate = Math.round(newSalary);

            renderTable();
            alert("Salary information updated successfully!");
            closeModal();
        });

        document.addEventListener("DOMContentLoaded", () => {
            byId("searchInput").addEventListener("input", renderTable);
            byId("statusFilter").addEventListener("change", renderTable);
            byId("subtitle").addEventListener("click", () => { activeSiteFilter = "all"; renderTable(); });
            byId("btnClearSite").addEventListener("click", () => { activeSiteFilter = "all"; renderTable(); });
            byId("btnPayDetails").addEventListener("click", () => {
                if (activeSiteFilter === "all") return;
                const hash = siteToPayrollHash[activeSiteFilter];
                if (!hash) return;
                window.location.href = "" + page("payroll") + "#payroll-" + hash;
            });
            renderTable();
        });

