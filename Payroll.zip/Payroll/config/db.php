<?php
declare(strict_types=1);

// MySQL connection settings (XAMPP defaults shown).
// You can override any value using environment variables:
// DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS

return [
    'host' => getenv('DB_HOST') !== false ? (string) getenv('DB_HOST') : '127.0.0.1',
    'port' => getenv('DB_PORT') !== false ? (int) getenv('DB_PORT') : 3306,
    'name' => getenv('DB_NAME') !== false ? (string) getenv('DB_NAME') : 'payroll_system',
    'user' => getenv('DB_USER') !== false ? (string) getenv('DB_USER') : 'root',
    'pass' => getenv('DB_PASS') !== false ? (string) getenv('DB_PASS') : '',
    'charset' => 'utf8mb4',
];

