<?php
declare(strict_types=1);

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function i($v): string {
    return (string) intval($v);
}

$notificationCount = 1;

$assignedSites = [
    'main-street' => [
        'name' => 'Main Street Project',
        'workers' => 15,
        'attendance_present' => 12,
        'attendance_total' => 15,
        'status' => 'ACTIVE',
    ],
    'downtown' => [
        'name' => 'Downtown Office Complex',
        'workers' => 10,
        'attendance_present' => 9,
        'attendance_total' => 10,
        'status' => 'ACTIVE',
    ],
];
// Try load sites from MySQL (if configured). If it fails, keep demo data.
try {
    require_once __DIR__ . '/lib/repo.php';
    $pdo = db();
    $assignedSites = repo_assigned_sites($pdo);
} catch (Throwable $e) {
    // Keep demo data.
}?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Philippians CDO - Payroll Processing</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 200px;
            background: linear-gradient(135deg, #c8652f 0%, #9a4f22 100%);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 20px 25px;
            font-size: 18px;
            font-weight: 700;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            margin-bottom: 25px;
            letter-spacing: 0.5px;
        }

        .sidebar-section {
            margin-bottom: 25px;
            padding: 0 12px;
        }

        .sidebar-section-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.5);
            padding: 0 8px 10px;
            letter-spacing: 0.8px;
        }

        .sidebar-item {
            display: flex;
            align-items: center;
            padding: 11px 12px;
            margin-bottom: 6px;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.9);
            transition: all 0.25s ease;
            font-size: 13px;
            font-weight: 500;
        }

        .sidebar-item:hover {
            background-color: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .sidebar-item.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            font-weight: 600;
        }

        .sidebar-item i {
            margin-right: 12px;
            width: 16px;
            text-align: center;
            font-size: 15px;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px;
            flex: 1;
            padding: 25px 35px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 25px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .page-title {
            font-size: 26px;
            font-weight: 700;
            color: #2c3e50;
            letter-spacing: -0.5px;
        }

        .page-subtitle {
            font-size: 12px;
            color: #9ca3af;
            margin-top: 5px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .notification-bell {
            font-size: 20px;
            cursor: pointer;
            color: #ff6b6b;
            position: relative;
            transition: transform 0.3s ease;
        }

        .notification-bell:hover {
            transform: scale(1.1);
        }

        .notification-badge {
            position: absolute;
            background: #ff6b6b;
            color: white;
            border-radius: 50%;
            width: 22px;
            height: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            font-weight: bold;
            top: -8px;
            right: -8px;
        }

        .payroll-staff {
            background: linear-gradient(135deg, #f5f7fa 0%, #f0f3f7 100%);
            padding: 10px 18px;
            border-radius: 6px;
            color: #555;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid #e5e7eb;
            font-weight: 500;
        }

        .payroll-staff i {
            font-size: 15px;
            color: #666;
        }

        /* Sites Section */
        .sites-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            margin-bottom: 30px;
        }

        .sites-title {
            font-size: 16px;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 25px;
            letter-spacing: -0.3px;
        }

        .sites-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }

        .site-card {
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 22px;
            background: #fafbfc;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .site-card:hover {
            border-color: #d1d5db;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .site-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .site-name {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 14px;
        }

        .site-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #ffe5cc 0%, #ffd9b3 100%);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ff9800;
            font-size: 20px;
        }

        .site-status {
            background: #d4edda;
            color: #155724;
            padding: 5px 13px;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .site-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        .detail-item {
            color: #555;
        }

        .detail-label {
            color: #9ca3af;
            font-size: 11px;
            margin-bottom: 5px;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.3px;
        }

        .detail-value {
            font-weight: 700;
            color: #1f2937;
            font-size: 16px;
        }

        .site-action-btn {
            width: 100%;
            padding: 11px 16px;
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(40, 167, 69, 0.2);
        }

        .site-action-btn:hover {
            background: linear-gradient(135deg, #1e7e34 0%, #155724 100%);
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
            transform: translateY(-1px);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .sites-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
                padding: 15px 0;
            }

            .sidebar-header {
                font-size: 12px;
                padding: 0 5px;
            }

            .sidebar-item {
                justify-content: center;
                padding: 11px 5px;
            }

            .sidebar-item span {
                display: none;
            }

            .main-content {
                margin-left: 60px;
                padding: 15px;
            }

            .sites-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">Philippians CDO</div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Overview</div>
                <a href="payroll.php" class="sidebar-item">
                    <i class="fas fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Operations</div>
                <a href="payroll-process.php" class="sidebar-item active">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Payroll Processing</span>
                </a>
                <a href="attendance.php" class="sidebar-item">
                    <i class="fas fa-calendar-check"></i>
                    <span>Attendance</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Workforce</div>
                <a href="worker.php" class="sidebar-item">
                    <i class="fas fa-users"></i>
                    <span>Worker</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">Reports</div>
                <a href="report.php" class="sidebar-item">
                    <i class="fas fa-file-csv"></i>
                    <span>Payroll Report</span>
                </a>
                <a href="#" class="sidebar-item">
                    <i class="fas fa-history"></i>
                    <span>History</span>
                </a>
                <a href="#" class="sidebar-item">
                    <i class="fas fa-archive"></i>
                    <span>Archive</span>
                </a>
            </div>

            <div class="sidebar-section">
                <a href="#" class="sidebar-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Payroll Processing Page -->
            <div class="header">
                <div>
                    <div class="page-title">Payroll Processing</div>
                    <div class="page-subtitle">Select a Construction Site to Process Payroll</div>
                </div>
                <div class="header-right">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge"><?= i($notificationCount) ?></span>
                    </div>
                    <div class="payroll-staff">
                        <i class="fas fa-user"></i>
                        <span>Payroll Staff</span>
                    </div>
                </div>
            </div>

            <div class="sites-section">
                <div class="sites-title">Construction Sites Assigned</div>
                <div class="sites-grid">
                    <!-- Main Street Project -->
                    <div class="site-card">
                        <div class="site-header">
                            <div class="site-name">
                                <div class="site-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div><?= h($assignedSites["main-street"]["name"]) ?></div>
                            </div>
                            <div class="site-status"><?= h($assignedSites["main-street"]["status"]) ?></div>
                        </div>
                        <div class="site-details">
                            <div class="detail-item">
                                <div class="detail-label">Workers:</div>
                                <div class="detail-value"><?= i($assignedSites["main-street"]["workers"]) ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Today's Attendance:</div>
                                <div class="detail-value"><?= i($assignedSites["main-street"]["attendance_present"]) ?>/<?= i($assignedSites["main-street"]["attendance_total"]) ?></div>
                            </div>
                        </div>
                        <button class="site-action-btn" onclick="processPayroll('main-street')">
                            <i class="fas fa-arrow-right" style="margin-right: 8px;"></i>View Details
                        </button>
                    </div>

                    <!-- Downtown Office Complex -->
                    <div class="site-card">
                        <div class="site-header">
                            <div class="site-name">
                                <div class="site-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div><?= h($assignedSites["downtown"]["name"]) ?></div>
                            </div>
                            <div class="site-status"><?= h($assignedSites["downtown"]["status"]) ?></div>
                        </div>
                        <div class="site-details">
                            <div class="detail-item">
                                <div class="detail-label">Workers:</div>
                                <div class="detail-value"><?= i($assignedSites["downtown"]["workers"]) ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Today's Attendance:</div>
                                <div class="detail-value"><?= i($assignedSites["downtown"]["attendance_present"]) ?>/<?= i($assignedSites["downtown"]["attendance_total"]) ?></div>
                            </div>
                        </div>
                        <button class="site-action-btn" onclick="processPayroll('downtown')">
                            <i class="fas fa-arrow-right" style="margin-right: 8px;"></i>View Details
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/payroll-process.js" defer></script>
</body>
</html>

