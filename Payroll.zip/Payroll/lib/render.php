<?php
declare(strict_types=1);

// Shared helpers for PHP-rendered pages.
// Keeps the "original" HTML designs, while making internal navigation work via .php routes.

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function i(mixed $v): string {
    return (string) intval($v);
}

/**
 * Render an HTML file while rewriting internal .html links to .php.
 *
 * This keeps your HTML pages as the design source-of-truth and avoids duplicating
 * large templates in multiple PHP files.
 *
 * @param array{head_inject?:string, body_inject_end?:string} $opts
 */
function render_html_with_php_links(string $htmlPath, array $opts = []): void {
    $html = @file_get_contents($htmlPath);
    if ($html === false) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Failed to read HTML template: ' . $htmlPath;
        return;
    }

    // Update common string occurrences inside inline JS.
    $html = str_replace('.html#', '.php#', $html);

    // Rewrite href/src that point to local *.html files into *.php.
    $html = preg_replace_callback(
        '/\b(href|src)=([\'\"])([^\'\"]+)\.html(\#[^\'\"]*)?\2/i',
        static function (array $m): string {
            $attr = $m[1];
            $q = $m[2];
            $path = $m[3];
            $hash = $m[4] ?? '';

            // Skip external-ish links or anchors.
            $lower = strtolower($path);
            if (
                str_starts_with($lower, 'http://') ||
                str_starts_with($lower, 'https://') ||
                str_starts_with($lower, '//') ||
                str_starts_with($lower, '#') ||
                str_starts_with($lower, 'mailto:') ||
                str_starts_with($lower, 'javascript:')
            ) {
                return $m[0];
            }

            return $attr . '=' . $q . $path . '.php' . $hash . $q;
        },
        $html
    );

    if (!empty($opts['head_inject'])) {
        $inject = (string) $opts['head_inject'];
        if (stripos($html, '</head>') !== false) {
            $html = preg_replace('/<\/head>/i', $inject . "\n</head>", $html, 1);
        } else {
            $html = $inject . "\n" . $html;
        }
    }

    if (!empty($opts['body_inject_end'])) {
        $inject = (string) $opts['body_inject_end'];
        if (stripos($html, '</body>') !== false) {
            $html = preg_replace('/<\/body>/i', $inject . "\n</body>", $html, 1);
        } else {
            $html .= "\n" . $inject;
        }
    }

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
}