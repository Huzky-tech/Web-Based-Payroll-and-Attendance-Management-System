<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function repo_site_payroll_data(PDO $pdo): array {
    $sites = db_all($pdo, 'SELECT slug, name FROM sites ORDER BY name');

    $data = [];
    foreach ($sites as $s) {
        $slug = (string) $s['slug'];
        $data[$slug] = [
            'name' => (string) $s['name'],
            'period' => '',
            'workers' => [],
        ];

        $period = db_one(
            $pdo,
            'SELECT id, period_label FROM payroll_periods WHERE site_slug = ? ORDER BY created_at DESC, id DESC LIMIT 1',
            [$slug]
        );
        if (!$period) continue;

        $periodId = (int) $period['id'];
        $data[$slug]['period'] = (string) $period['period_label'];

        $rows = db_all(
            $pdo,
            'SELECT w.full_name AS name, w.role AS role, e.days, e.gross, e.deductions, e.status
             FROM payroll_entries e
             JOIN workers w ON w.id = e.worker_id
             WHERE e.period_id = ?
             ORDER BY w.full_name',
            [$periodId]
        );

        foreach ($rows as $r) {
            $data[$slug]['workers'][] = [
                'name' => (string) $r['name'],
                'role' => (string) $r['role'],
                'days' => (int) $r['days'],
                'gross' => (float) $r['gross'],
                'deductions' => (float) $r['deductions'],
                'status' => (string) $r['status'],
            ];
        }
    }

    return $data;
}

function repo_stats(PDO $pdo): array {
    $total = db_one($pdo, 'SELECT COUNT(*) AS c FROM workers');
    $onLeave = db_one($pdo, 'SELECT COUNT(*) AS c FROM workers WHERE status = ?', ['onleave']);
    $openPeriods = db_one($pdo, 'SELECT COUNT(*) AS c FROM payroll_periods WHERE status = ?', ['open']);

    return [
        'total_employees' => (int) (($total['c'] ?? 0)),
        'on_leave' => (int) (($onLeave['c'] ?? 0)),
        'processing' => (int) (($openPeriods['c'] ?? 0)),
    ];
}

function repo_assigned_sites(PDO $pdo): array {
    $sites = db_all($pdo, 'SELECT slug, name, status FROM sites ORDER BY name');
    $out = [];

    foreach ($sites as $s) {
        $slug = (string) $s['slug'];
        $workers = db_one($pdo, 'SELECT COUNT(*) AS c FROM workers WHERE site_slug = ?', [$slug]);
        $lastDate = db_one($pdo, 'SELECT MAX(work_date) AS d FROM attendance_records WHERE site_slug = ?', [$slug]);
        $d = $lastDate && !empty($lastDate['d']) ? (string) $lastDate['d'] : null;

        $present = 0;
        $total = (int) (($workers['c'] ?? 0));
        if ($d) {
            $presentRow = db_one(
                $pdo,
                'SELECT COUNT(*) AS c FROM attendance_records WHERE site_slug = ? AND work_date = ? AND status IN ("present","late")',
                [$slug, $d]
            );
            $present = (int) (($presentRow['c'] ?? 0));
        }

        $out[$slug] = [
            'name' => (string) $s['name'],
            'workers' => $total,
            'attendance_present' => $present,
            'attendance_total' => $total,
            'status' => (string) ($s['status'] ?? 'ACTIVE'),
        ];
    }

    return $out;
}

function repo_workers_ui_data(PDO $pdo): array {
    $rows = db_all(
        $pdo,
        'SELECT w.emp_code, w.full_name, w.role, w.status, w.daily_rate, w.hired_date, s.name AS site_name, s.slug AS site_slug
         FROM workers w
         JOIN sites s ON s.slug = w.site_slug
         ORDER BY s.name, w.full_name'
    );

    $employees = [];
    foreach ($rows as $r) {
        $employees[] = [
            'id' => (string) $r['emp_code'],
            'name' => (string) $r['full_name'],
            'position' => (string) $r['role'],
            'site' => (string) $r['site_name'],
            'status' => (string) $r['status'],
            'dailyRate' => (float) $r['daily_rate'],
            'date' => $r['hired_date'] ? (string) $r['hired_date'] : null,
        ];
    }

    $siteRows = db_all($pdo, 'SELECT slug, name FROM sites ORDER BY name');
    $sites = [];
    $map = [];
    foreach ($siteRows as $s) {
        $sites[] = [
            'key' => (string) $s['name'],
            'subtitle' => 'Assigned workers',
        ];
        $map[(string) $s['name']] = (string) $s['slug'];
    }

    return [
        'employees' => $employees,
        'sites' => $sites,
        'siteToPayrollHash' => $map,
    ];
}

function repo_attendance_ui_data(PDO $pdo): array {
    $siteRows = db_all($pdo, 'SELECT slug, name FROM sites ORDER BY name');

    $sites = [];
    foreach ($siteRows as $s) {
        $sites[] = [
            'id' => (string) $s['slug'],
            'name' => (string) $s['name'],
            'icon' => 'fa-building',
        ];
    }

    $rows = db_all(
        $pdo,
        'SELECT a.site_slug, a.work_date, a.status, a.time_in, a.time_out, a.hours_worked,
                w.full_name, w.emp_code
         FROM attendance_records a
         JOIN workers w ON w.id = a.worker_id
         ORDER BY a.work_date DESC, a.site_slug, w.full_name'
    );

    $palette = [
        'linear-gradient(135deg, #3b82f6, #1e40af)',
        'linear-gradient(135deg, #a855f7, #7e22ce)',
        'linear-gradient(135deg, #8b5cf6, #6d28d9)',
        'linear-gradient(135deg, #0ea5e9, #0284c7)',
        'linear-gradient(135deg, #f59e0b, #d97706)',
        'linear-gradient(135deg, #f97316, #c2410c)',
        'linear-gradient(135deg, #06b6d4, #0891b2)',
        'linear-gradient(135deg, #14b8a6, #0d9488)',
        'linear-gradient(135deg, #f43f5e, #be185d)',
        'linear-gradient(135deg, #10b981, #059669)',
        'linear-gradient(135deg, #ec4899, #be185d)'
    ];

    $records = [];
    foreach ($rows as $r) {
        $name = (string) $r['full_name'];
        $emp = (string) $r['emp_code'];

        $initials = '';
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        foreach ($parts as $p) {
            if ($p === '') continue;
            $initials .= strtoupper($p[0]);
            if (strlen($initials) >= 2) break;
        }

        $idx = (int) (abs((int) crc32($emp)) % count($palette));

        $dateStr = (string) $r['work_date'];
        $prettyDate = $dateStr;
        $ts = strtotime($dateStr);
        if ($ts !== false) $prettyDate = date('M j, Y', $ts);

        $ti = $r['time_in'] ? date('h:i A', strtotime((string) $r['time_in'])) : '-';
        $to = $r['time_out'] ? date('h:i A', strtotime((string) $r['time_out'])) : '-';
        $hours = number_format((float) $r['hours_worked'], 2);

        $records[] = [
            'siteId' => (string) $r['site_slug'],
            'name' => $name,
            'empId' => $emp,
            'status' => (string) $r['status'],
            'timeIn' => $ti,
            'timeOut' => $to,
            'hours' => rtrim(rtrim($hours, '0'), '.') . ' hrs',
            'date' => $prettyDate,
            'avatar' => $initials !== '' ? $initials : 'U',
            'avatarBg' => $palette[$idx],
        ];
    }

    return [
        'sites' => $sites,
        'records' => $records,
    ];
}