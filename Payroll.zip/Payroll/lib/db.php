<?php
declare(strict_types=1);

/**
 * PDO database connection (MySQL).
 *
 * Usage:
 *   $pdo = db();
 */
function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $cfgPath = __DIR__ . '/../config/db.php';
    if (!is_file($cfgPath)) {
        throw new RuntimeException('Missing DB config: ' . $cfgPath);
    }

    /** @var array{host:string,port:int,name:string,user:string,pass:string,charset:string} $cfg */
    $cfg = require $cfgPath;

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $cfg['host'],
        $cfg['port'],
        $cfg['name'],
        $cfg['charset']
    );

    $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

/**
 * Convenience: fetch all rows.
 * @return array<int, array<string, mixed>>
 */
function db_all(PDO $pdo, string $sql, array $params = []): array {
    $st = $pdo->prepare($sql);
    $st->execute($params);
    /** @var array<int, array<string, mixed>> */
    return $st->fetchAll();
}

/**
 * Convenience: fetch first row.
 * @return array<string, mixed>|null
 */
function db_one(PDO $pdo, string $sql, array $params = []): ?array {
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}
