<?php
declare(strict_types=1);

require __DIR__ . '/lib/render.php';

$payload = null;
try {
    require_once __DIR__ . '/lib/repo.php';
    $pdo = db();
    $payload = repo_workers_ui_data($pdo);
} catch (Throwable $e) {
    $payload = null;
}

$head = '';
if (is_array($payload)) {
    $jEmployees = json_encode($payload['employees'] ?? null, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $jSites = json_encode($payload['sites'] ?? null, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $jMap = json_encode($payload['siteToPayrollHash'] ?? null, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    if ($jEmployees !== false && $jSites !== false && $jMap !== false) {
        $head = "<script>" .
            "window.workerEmployees = " . $jEmployees . ";" .
            "window.workerSites = " . $jSites . ";" .
            "window.workerSiteToPayrollHash = " . $jMap . ";" .
            "</script>";
    }
}

render_html_with_php_links(__DIR__ . '/worker.html', [
    'head_inject' => $head,
]);