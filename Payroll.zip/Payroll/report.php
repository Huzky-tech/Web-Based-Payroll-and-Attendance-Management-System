<?php
declare(strict_types=1);

require __DIR__ . '/lib/render.php';

$sitePayrollData = null;
try {
    require_once __DIR__ . '/lib/repo.php';
    $pdo = db();
    $sitePayrollData = repo_site_payroll_data($pdo);
} catch (Throwable $e) {
    $sitePayrollData = null;
}

$head = '';
if (is_array($sitePayrollData)) {
    $json = json_encode($sitePayrollData, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if ($json !== false) {
        $head = "<script>window.sitePayrollData = " . $json . ";</script>";
    }
}

render_html_with_php_links(__DIR__ . '/report.html', [
    'head_inject' => $head,
]);