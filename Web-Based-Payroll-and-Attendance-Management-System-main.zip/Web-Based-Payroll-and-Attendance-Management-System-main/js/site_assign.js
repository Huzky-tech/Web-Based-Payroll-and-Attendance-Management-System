let staff = [];
let sites = [];
let assignments = [];
let selectedStaffId = null;
let selectedStaffName = null;

/* ===================== DATE & TIME ===================== */
function updateDateTime() {
    const now = new Date();
    document.getElementById('currentDate').textContent =
        now.toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
    document.getElementById('currentTime').textContent =
        now.toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' });
}
updateDateTime();
setInterval(updateDateTime, 60000);

/* ===================== FETCH DATA ===================== */
async function fetchStaff() {
    try {
        const response = await fetch('get_staff.php');
        staff = await response.json();
        renderStaffList();
        updateSummary();
    } catch (error) {
        console.error('Error fetching staff:', error);
    }
}

async function fetchSites() {
    try {
        const response = await fetch('get_sites.php');
        sites = await response.json();
    } catch (error) {
        console.error('Error fetching sites:', error);
    }
}

async function fetchAssignments(staffId) {
    try {
        const response = await fetch(`get_assignments.php?staff_id=${staffId}`);
        assignments = await response.json();
        return assignments;
    } catch (error) {
        console.error('Error fetching assignments:', error);
        return [];
    }
}

/* ===================== STAFF SELECTION ===================== */
async function selectStaff(staffId, staffName) {
    selectedStaffId = staffId;
    selectedStaffName = staffName;

    document.querySelectorAll('.staff-item').forEach(i => i.classList.remove('selected'));
    document.querySelector(`[data-staff="${staffId}"]`).classList.add('selected');

    document.getElementById('emptyState').style.display = 'none';
    document.getElementById('sitesContent').style.display = 'block';

    document.getElementById('panelTitle').textContent = `Assign Sites to ${staffName}`;

    await fetchAssignments(staffId);
    document.getElementById('panelSubtitle').textContent =
        `${assignments.length} active assignments`;

    renderSites();
}

/* ===================== RENDER STAFF LIST ===================== */
function renderStaffList() {
    const staffList = document.getElementById('staffList');
    staffList.innerHTML = '';

    staff.forEach(s => {
        const badgeHtml = s.site_count > 0 ?
            `<span class="staff-sites-badge">${s.site_count} Site${s.site_count > 1 ? 's' : ''}</span>` : '';

        staffList.innerHTML += `
            <div class="staff-item" data-staff="${s.staff_id}" onclick="selectStaff('${s.staff_id}', '${s.name}')">
                <div class="staff-item-header">
                    <div class="staff-name">${s.name}</div>
                    ${badgeHtml}
                </div>
                <div class="staff-email">${s.email}</div>
            </div>`;
    });
}

/* ===================== RENDER SITES ===================== */
function renderSites() {
    const sitesList = document.getElementById('sitesList');
    sitesList.innerHTML = '';

    sites.forEach(site => {
        const assigned = assignments.some(a => a.name === site.name);

        sitesList.innerHTML += `
            <div class="site-item ${site.status === 'inactive' ? 'inactive' : ''}">
                <div class="site-item-header">
                    <div>
                        <div class="site-name">${site.name}</div>
                        <div class="site-address">${site.location || 'Address not specified'}</div>
                    </div>
                    <button class="site-action ${assigned ? 'remove' : 'add'}"
                        onclick="${assigned
                            ? `removeSite('${site.name}')`
                            : `addSite('${site.name}')`}">
                        <i class="fas ${assigned ? 'fa-trash' : 'fa-plus'}"></i>
                    </button>
                </div>
                <span class="site-status ${site.status}">${site.status}</span>
                <div class="site-details">
                    <div>Site ID: ${site.id}</div>
                    <div>Status: ${site.status}</div>
                </div>
            </div>`;
    });
}

/* ===================== ADD / REMOVE SITE ===================== */
async function addSite(siteName) {
    try {
        const formData = new FormData();
        formData.append('staff_id', selectedStaffId);
        formData.append('site_name', siteName);
        formData.append('user', 'Admin User');

        const response = await fetch('add_assignment.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (result.success) {
            await fetchAssignments(selectedStaffId);
            await fetchStaff(); // Refresh staff list to update badges
            selectStaff(selectedStaffId, selectedStaffName);
        } else {
            alert('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error adding assignment:', error);
        alert('Error adding assignment');
    }
}

async function removeSite(siteName) {
    try {
        const formData = new FormData();
        formData.append('staff_id', selectedStaffId);
        formData.append('site_name', siteName);
        formData.append('user', 'Admin User');

        const response = await fetch('remove_assignment.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (result.success) {
            await fetchAssignments(selectedStaffId);
            await fetchStaff(); // Refresh staff list to update badges
            selectStaff(selectedStaffId, selectedStaffName);
        } else {
            alert('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error removing assignment:', error);
        alert('Error removing assignment');
    }
}

/* ===================== SUMMARY ===================== */
function updateSummary() {
    const totalStaff = staff.length;
    const activeSites = sites.filter(s => s.status === 'active').length;
    const totalAssignments = staff.reduce((sum, s) => sum + s.site_count, 0);

    document.querySelector('.summary-value:nth-child(1)').textContent = totalStaff;
    document.querySelector('.summary-value:nth-child(2)').textContent = activeSites;
    document.querySelector('.summary-value:nth-child(3)').textContent = totalAssignments;
}

/* ===================== AUDIT LOG ===================== */
async function viewAuditLog() {
    try {
        const response = await fetch('get_audit_logs.php');
        const logs = await response.json();

        if (logs.length === 0) {
            alert('No audit records yet.');
            return;
        }

        const logText = logs
            .map(l => `[${l.time}] ${l.user}: ${l.action}`)
            .join('\n');

        alert(logText);
    } catch (error) {
        console.error('Error fetching audit logs:', error);
        alert('Error loading audit logs');
    }
}

/* ===================== SEARCH ===================== */
function filterStaff() {
    const filter = document.getElementById('staffSearch').value.toLowerCase();
    document.querySelectorAll('.staff-item').forEach(item => {
        item.style.display =
            item.innerText.toLowerCase().includes(filter) ? 'block' : 'none';
    });
}

/* ===================== INIT ===================== */
document.addEventListener('DOMContentLoaded', () => {
    fetchStaff();
    fetchSites();
});
