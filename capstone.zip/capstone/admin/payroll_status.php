<?php
if (!isset($conn) || !($conn instanceof mysqli)) {
    include __DIR__ . '/../api/connection/db_config.php';
}

$records = [];
$summary = [
    'count' => 0,
    'gross' => 0,
    'deductions' => 0,
    'net' => 0
];

$result = $conn->query("
    SELECT 
        pr.Payroll_RecordsID,
        pr.SiteID,
        pr.Period_start,
        pr.Period_end,
        pr.Total_gross_pay,
        pr.Total_deductions,
        pr.Total_net_pay,
        pr.Status,
        ps.Site_Name
    FROM payroll_records pr
    INNER JOIN projectsite ps ON pr.SiteID = ps.SiteID
    ORDER BY pr.Period_end DESC, ps.Site_Name
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
        $summary['count']++;
        $summary['gross'] += (float) ($row['Total_gross_pay'] ?? 0);
        $summary['deductions'] += (float) ($row['Total_deductions'] ?? 0);
        $summary['net'] += (float) ($row['Total_net_pay'] ?? 0);
    }
}
?>
<div class="content-area">
    <div class="page-header">
        <h1>Payroll Status</h1>
        <p>Track processed payroll batches and monitor their totals by site and pay period.</p>
    </div>

    <div class="summary-cards">
        <div class="summary-card">
            <div class="summary-card-icon blue"><i class="fas fa-folder-open"></i></div>
            <div class="summary-card-content">
                <div class="summary-card-label">Processed Batches</div>
                <div class="summary-card-value"><?php echo (int) $summary['count']; ?></div>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-card-icon red"><i class="fas fa-file-invoice-dollar"></i></div>
            <div class="summary-card-content">
                <div class="summary-card-label">Total Gross</div>
                <div class="summary-card-value">PHP <?php echo number_format($summary['gross'], 2); ?></div>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-card-icon green"><i class="fas fa-wallet"></i></div>
            <div class="summary-card-content">
                <div class="summary-card-label">Total Net</div>
                <div class="summary-card-value">PHP <?php echo number_format($summary['net'], 2); ?></div>
            </div>
        </div>
    </div>

    <div class="payroll-table-container">
        <div class="section-title">Processed Payroll Records</div>
        <table class="payroll-table">
            <thead>
                <tr>
                    <th>Site</th>
                    <th>Period</th>
                    <th>Status</th>
                    <th>Gross Pay</th>
                    <th>Deductions</th>
                    <th>Net Pay</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($records) === 0): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">No payroll batches have been processed yet.</td>
                </tr>
                <?php else: ?>
                <?php foreach ($records as $record): ?>
                <tr>
                    <td><?php echo htmlspecialchars($record['Site_Name']); ?></td>
                    <td><?php echo htmlspecialchars(date('M d, Y', strtotime($record['Period_start'])) . ' - ' . date('M d, Y', strtotime($record['Period_end']))); ?></td>
                    <td><?php echo htmlspecialchars($record['Status']); ?></td>
                    <td>PHP <?php echo number_format((float) $record['Total_gross_pay'], 2); ?></td>
                    <td>PHP <?php echo number_format((float) $record['Total_deductions'], 2); ?></td>
                    <td>PHP <?php echo number_format((float) $record['Total_net_pay'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
