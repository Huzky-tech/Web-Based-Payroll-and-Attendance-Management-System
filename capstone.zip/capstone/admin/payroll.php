<?php
if (!isset($conn) || !($conn instanceof mysqli)) {
    include __DIR__ . '/../api/connection/db_config.php';
}

function derive_pay_period(string $payPeriods): array {
    $today = new DateTime('today');
    $normalized = strtolower($payPeriods);

    if (strpos($normalized, 'semi') !== false) {
        if ((int) $today->format('d') <= 15) {
            $start = new DateTime($today->format('Y-m-01'));
            $end = new DateTime($today->format('Y-m-15'));
        } else {
            $start = new DateTime($today->format('Y-m-16'));
            $end = new DateTime($today->format('Y-m-t'));
        }
    } else {
        $start = new DateTime($today->format('Y-m-01'));
        $end = new DateTime($today->format('Y-m-t'));
    }

    return [
        'start' => $start->format('Y-m-d'),
        'end' => $end->format('Y-m-d'),
        'label' => $start->format('M d') . ' - ' . $end->format('M d, Y')
    ];
}

$settingsResult = $conn->query("SELECT * FROM payroll_settings WHERE id = 1 LIMIT 1");
$payrollSettings = $settingsResult ? $settingsResult->fetch_assoc() : null;
$payrollSettings = $payrollSettings ?: [
    'pay_periods' => 'Semi-monthly (1-15, 16-end)',
    'sss_rate' => 0,
    'philhealth_rate' => 3,
    'pagibig_rate' => 2,
    'overtime_rate' => 1.25
];

$payPeriod = derive_pay_period((string) $payrollSettings['pay_periods']);
$deductionRate = (
    (float) ($payrollSettings['sss_rate'] ?? 0) +
    (float) ($payrollSettings['philhealth_rate'] ?? 0) +
    (float) ($payrollSettings['pagibig_rate'] ?? 0)
) / 100;
$overtimeRate = (float) ($payrollSettings['overtime_rate'] ?? 1.25);

$recordsMap = [];
$recordSql = $conn->prepare("
    SELECT SiteID, Payroll_RecordsID, Status
    FROM payroll_records
    WHERE Period_start = ? AND Period_end = ?
");
$recordSql->bind_param("ss", $payPeriod['start'], $payPeriod['end']);
$recordSql->execute();
$recordResult = $recordSql->get_result();
while ($row = $recordResult->fetch_assoc()) {
    $recordsMap[(int) $row['SiteID']] = $row;
}
$recordSql->close();

$sites = [];
$sitesQuery = $conn->query("
    SELECT 
        ps.SiteID,
        ps.Site_Name,
        ps.Location,
        ps.Status,
        COUNT(DISTINCT wa.WorkerID) AS assigned_workers
    FROM projectsite ps
    LEFT JOIN workerassignment wa ON wa.SiteID = ps.SiteID
    GROUP BY ps.SiteID, ps.Site_Name, ps.Location, ps.Status
    ORDER BY ps.Site_Name
");

$sitePayrollCards = [];
$summaryTotals = [
    'sites' => 0,
    'workers' => 0,
    'gross' => 0,
    'net' => 0,
    'processed' => 0
];

$workerStmt = $conn->prepare("
    SELECT 
        w.WorkerID,
        w.First_Name,
        w.Last_Name,
        w.RateType,
        w.RateAmount,
        COALESCE(SUM(a.Hours_Worked), 0) AS total_hours,
        COALESCE(SUM(a.Overtime_Hours), 0) AS overtime_hours,
        SUM(CASE WHEN a.AttendanceStatus = 'Present' THEN 1 ELSE 0 END) AS present_days,
        SUM(CASE WHEN a.AttendanceStatus = 'Late' THEN 1 ELSE 0 END) AS late_days
    FROM workerassignment wa
    INNER JOIN worker w ON wa.WorkerID = w.WorkerID
    LEFT JOIN attendance a
        ON a.WorkerID = w.WorkerID
        AND a.SiteID = wa.SiteID
        AND a.Date BETWEEN ? AND ?
    WHERE wa.SiteID = ?
    GROUP BY w.WorkerID, w.First_Name, w.Last_Name, w.RateType, w.RateAmount
    ORDER BY w.Last_Name, w.First_Name
");

while ($site = $sitesQuery->fetch_assoc()) {
    $siteId = (int) $site['SiteID'];
    $siteWorkers = [];
    $siteGross = 0;
    $siteNet = 0;
    $siteDeductions = 0;

    $workerStmt->bind_param("ssi", $payPeriod['start'], $payPeriod['end'], $siteId);
    $workerStmt->execute();
    $workerResult = $workerStmt->get_result();

    while ($worker = $workerResult->fetch_assoc()) {
        $rateType = strtolower((string) ($worker['RateType'] ?? 'hourly'));
        $rateAmount = (float) ($worker['RateAmount'] ?? 0);
        $totalHours = (float) ($worker['total_hours'] ?? 0);
        $overtimeHours = (float) ($worker['overtime_hours'] ?? 0);
        $regularHours = max(0, $totalHours - $overtimeHours);

        if ($rateType === 'salary') {
            $grossPay = $rateAmount;
        } else {
            $grossPay = ($regularHours * $rateAmount) + ($overtimeHours * $rateAmount * $overtimeRate);
        }

        $deductions = round($grossPay * $deductionRate, 2);
        $netPay = round($grossPay - $deductions, 2);

        $siteWorkers[] = [
            'WorkerID' => (int) $worker['WorkerID'],
            'full_name' => trim(($worker['First_Name'] ?? '') . ' ' . ($worker['Last_Name'] ?? '')),
            'rate_type' => $worker['RateType'] ?: 'Hourly',
            'rate_amount' => round($rateAmount, 2),
            'present_days' => (int) ($worker['present_days'] ?? 0),
            'late_days' => (int) ($worker['late_days'] ?? 0),
            'attendance_days' => (int) (($worker['present_days'] ?? 0) + ($worker['late_days'] ?? 0)),
            'total_hours' => round($totalHours, 2),
            'overtime_hours' => round($overtimeHours, 2),
            'gross_pay' => round($grossPay, 2),
            'deductions' => $deductions,
            'net_pay' => $netPay
        ];

        $siteGross += $grossPay;
        $siteNet += $netPay;
        $siteDeductions += $deductions;
    }

    $processed = isset($recordsMap[$siteId]);

    $sitePayrollCards[] = [
        'SiteID' => $siteId,
        'Site_Name' => $site['Site_Name'],
        'Location' => $site['Location'],
        'Status' => $site['Status'],
        'assigned_workers' => (int) ($site['assigned_workers'] ?? 0),
        'period_label' => $payPeriod['label'],
        'gross_pay' => round($siteGross, 2),
        'deductions' => round($siteDeductions, 2),
        'net_pay' => round($siteNet, 2),
        'processed' => $processed,
        'workers' => $siteWorkers
    ];

    $summaryTotals['sites']++;
    $summaryTotals['workers'] += count($siteWorkers);
    $summaryTotals['gross'] += $siteGross;
    $summaryTotals['net'] += $siteNet;
    $summaryTotals['processed'] += $processed ? 1 : 0;
}

$workerStmt->close();
?>
<div class="content-area">
    <script>
        window.payrollPageData = <?php echo json_encode([
            'period' => $payPeriod,
            'settings' => [
                'pay_periods' => $payrollSettings['pay_periods'],
                'sss_rate' => (float) ($payrollSettings['sss_rate'] ?? 0),
                'philhealth_rate' => (float) ($payrollSettings['philhealth_rate'] ?? 0),
                'pagibig_rate' => (float) ($payrollSettings['pagibig_rate'] ?? 0),
                'overtime_rate' => (float) ($payrollSettings['overtime_rate'] ?? 1.25)
            ],
            'summary' => [
                'sites' => (int) $summaryTotals['sites'],
                'workers' => (int) $summaryTotals['workers'],
                'gross' => round($summaryTotals['gross'], 2),
                'net' => round($summaryTotals['net'], 2),
                'processed' => (int) $summaryTotals['processed']
            ],
            'sites' => $sitePayrollCards
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
    </script>

    <div class="page-view active" id="sitesPage">
        <div class="page-header">
            <h1>Payroll Processing</h1>
            <p>Review site-based payroll for the current pay period and process it into payroll records.</p>
        </div>

        <div class="summary-cards">
            <div class="summary-card">
                <div class="summary-card-icon blue"><i class="fas fa-building"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Sites This Period</div>
                    <div class="summary-card-value" id="payrollSitesCount"><?php echo (int) $summaryTotals['sites']; ?></div>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-icon green"><i class="fas fa-users"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Workers Included</div>
                    <div class="summary-card-value" id="payrollWorkersCount"><?php echo (int) $summaryTotals['workers']; ?></div>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-icon red"><i class="fas fa-check-circle"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Processed Sites</div>
                    <div class="summary-card-value" id="processedSitesCount"><?php echo (int) $summaryTotals['processed']; ?></div>
                </div>
            </div>
        </div>

        <div class="sites-container" id="payrollSitesContainer">
            <?php if (count($sitePayrollCards) === 0): ?>
            <div class="site-card">
                <div class="site-card-title">No sites available</div>
                <div class="site-info-item">Create site assignments to begin payroll processing.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="page-view" id="payrollDetailsPage">
        <div class="payroll-details-header">
            <button class="btn-back" id="btnBackToSites" type="button">
                <i class="fas fa-arrow-left"></i>
            </button>
            <div class="payroll-header-info">
                <h1 id="siteNameHeader">Site Payroll</h1>
                <p id="sitePeriodHeader"><?php echo htmlspecialchars($payPeriod['label']); ?></p>
            </div>
            <button class="btn-print-download" id="btnPrintPayroll" type="button">
                <i class="fas fa-print"></i>
                <span>Print / Download</span>
            </button>
        </div>

        <div class="summary-cards">
            <div class="summary-card">
                <div class="summary-card-icon blue"><i class="fas fa-wallet"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Gross Pay</div>
                    <div class="summary-card-value" id="grossPayValue">PHP 0.00</div>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-icon red"><i class="fas fa-minus-circle"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Deductions</div>
                    <div class="summary-card-value" id="deductionsValue">PHP 0.00</div>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-icon green"><i class="fas fa-money-bill-wave"></i></div>
                <div class="summary-card-content">
                    <div class="summary-card-label">Net Pay</div>
                    <div class="summary-card-value" id="netPayValue">PHP 0.00</div>
                </div>
            </div>
        </div>

        <div class="payroll-table-container">
            <div class="section-title" id="workersSectionTitle">Workers Assigned</div>
            <table class="payroll-table">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Attendance</th>
                        <th>Hours</th>
                        <th>Gross Pay</th>
                        <th>Deductions</th>
                        <th>Net Pay</th>
                    </tr>
                </thead>
                <tbody id="payrollTableBody"></tbody>
            </table>
        </div>

        <div class="process-payroll-section">
            <div class="process-note" id="processPayrollText">Process payroll for selected site.</div>
            <button class="btn-process-payroll" id="btnProcessPayroll" type="button">
                <i class="fas fa-money-check-dollar"></i>
                <span>Process Payroll</span>
            </button>
        </div>

        <div class="success-message" id="successMessage">
            <div class="success-icon"><i class="fas fa-check"></i></div>
            <div class="success-text" id="successMessageText">Payroll processed successfully.</div>
        </div>
    </div>
</div>
