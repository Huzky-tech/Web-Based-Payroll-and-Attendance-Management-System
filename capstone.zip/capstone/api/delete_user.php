<?php
header('Content-Type: application/json');
include 'connection/db_config.php';

function getUserRole($conn, $user_id) {
    $tables = [
        'admin' => 'Admin',
        'payrollstaff' => 'Payroll Staff',
        'hr' => 'HR',
        'timekeeper' => 'Timekeeper',
        'assistantmanager' => 'Assistant Manager'
    ];

    foreach ($tables as $table => $role) {
        $stmt = $conn->prepare("SELECT 1 FROM {$table} WHERE UserID = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            return $role;
        }
        $stmt->close();
    }

    return 'Worker';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$user_id = intval($_POST['user_id'] ?? 0);
$current_user_id = intval($_POST['current_user_id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid user ID']);
    exit;
}

// Prevent deleting yourself
if ($user_id == $current_user_id) {
    echo json_encode(['success' => false, 'message' => 'You cannot deactivate your own account']);
    exit;
}

// Check if user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit;
}

// Prevent deleting the last admin
$userRole = getUserRole($conn, $user_id);
if ($userRole === 'Admin') {
    // Count total admins
    $admin_count_stmt = $conn->prepare("
        SELECT COUNT(*) as count
        FROM admin a
        INNER JOIN users u ON a.UserID = u.id
        WHERE u.status = 'Active'
    ");
    $admin_count_stmt->execute();
    $admin_count_result = $admin_count_stmt->get_result();
    $admin_count = $admin_count_result->fetch_assoc()['count'];
    
    if ($admin_count <= 1) {
        echo json_encode(['success' => false, 'message' => 'Cannot deactivate the last admin account']);
        exit;
    }
}

try {
    // Soft delete - mark as inactive instead of deleting
    $stmt = $conn->prepare("UPDATE users SET status = 'Inactive' WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User deactivated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to deactivate user']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
