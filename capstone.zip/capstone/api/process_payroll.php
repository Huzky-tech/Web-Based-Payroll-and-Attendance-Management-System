<?php
header('Content-Type: application/json');
include 'connection/db_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$siteId = (int) ($data['site_id'] ?? 0);
$periodStart = $data['period_start'] ?? '';
$periodEnd = $data['period_end'] ?? '';

if ($siteId <= 0 || !$periodStart || !$periodEnd) {
    echo json_encode(['success' => false, 'message' => 'Site and pay period are required']);
    exit;
}

$siteStmt = $conn->prepare("SELECT SiteID, Site_Name FROM projectsite WHERE SiteID = ?");
if (!$siteStmt) {
    echo json_encode(['success' => false, 'message' => 'Failed to prepare site query: ' . $conn->error]);
    exit;
}
$siteStmt->bind_param("i", $siteId);
$siteStmt->execute();
$siteResult = $siteStmt->get_result();
$site = $siteResult->fetch_assoc();
$siteStmt->close();

if (!$site) {
    echo json_encode(['success' => false, 'message' => 'Site not found']);
    exit;
}

$existingStmt = $conn->prepare("
    SELECT Payroll_RecordsID
    FROM payroll_records
    WHERE SiteID = ? AND Period_start = ? AND Period_end = ?
    LIMIT 1
");
$existingStmt->bind_param("iss", $siteId, $periodStart, $periodEnd);
$existingStmt->execute();
$existingResult = $existingStmt->get_result();
$existingRecord = $existingResult->fetch_assoc();
$existingStmt->close();

if ($existingRecord) {
    echo json_encode(['success' => false, 'message' => 'Payroll for this site and period has already been processed']);
    exit;
}

$settingsResult = $conn->query("SELECT * FROM payroll_settings WHERE id = 1 LIMIT 1");
$settings = $settingsResult ? $settingsResult->fetch_assoc() : null;
if (!$settings) {
    echo json_encode(['success' => false, 'message' => 'Payroll settings not found']);
    exit;
}

$workerStmt = $conn->prepare("
    SELECT 
        w.WorkerID,
        w.First_Name,
        w.Last_Name,
        w.RateType,
        w.RateAmount,
        COALESCE(SUM(a.Hours_Worked), 0) AS total_hours,
        COALESCE(SUM(a.Overtime_Hours), 0) AS overtime_hours
    FROM workerassignment wa
    INNER JOIN worker w ON wa.WorkerID = w.WorkerID
    LEFT JOIN attendance a
        ON a.WorkerID = w.WorkerID
        AND a.SiteID = wa.SiteID
        AND a.Date BETWEEN ? AND ?
    WHERE wa.SiteID = ?
    GROUP BY w.WorkerID, w.First_Name, w.Last_Name, w.RateType, w.RateAmount
    ORDER BY w.Last_Name, w.First_Name
");

if (!$workerStmt) {
    echo json_encode(['success' => false, 'message' => 'Failed to prepare payroll worker query: ' . $conn->error]);
    exit;
}

$workerStmt->bind_param("ssi", $periodStart, $periodEnd, $siteId);
$workerStmt->execute();
$workersResult = $workerStmt->get_result();

$workers = [];
while ($row = $workersResult->fetch_assoc()) {
    $workers[] = $row;
}
$workerStmt->close();

if (count($workers) === 0) {
    echo json_encode(['success' => false, 'message' => 'No workers assigned to this site for payroll processing']);
    exit;
}

$deductionRate = (
    (float) ($settings['sss_rate'] ?? 0) +
    (float) ($settings['philhealth_rate'] ?? 0) +
    (float) ($settings['pagibig_rate'] ?? 0)
) / 100;
$overtimeRate = (float) ($settings['overtime_rate'] ?? 1.25);

$conn->begin_transaction();

try {
    $insertPayrollStmt = $conn->prepare("
        INSERT INTO payroll (
            WorkerID,
            Pay_Period_Start,
            Pay_Period_End,
            Gross_Pay,
            Total_Deductions,
            Net_Pay,
            Date_Processed
        ) VALUES (?, ?, ?, ?, ?, ?, CURDATE())
    ");

    if (!$insertPayrollStmt) {
        throw new Exception('Failed to prepare payroll insert: ' . $conn->error);
    }

    $totalGross = 0;
    $totalDeductions = 0;
    $totalNet = 0;
    $processedWorkers = 0;
    $firstPayrollId = null;

    foreach ($workers as $worker) {
        $rateType = strtolower((string) ($worker['RateType'] ?? 'hourly'));
        $rateAmount = (float) ($worker['RateAmount'] ?? 0);
        $totalHours = (float) ($worker['total_hours'] ?? 0);
        $overtimeHours = (float) ($worker['overtime_hours'] ?? 0);

        if ($rateType === 'salary') {
            $grossPay = $rateAmount;
        } else {
            $regularHours = max(0, $totalHours - $overtimeHours);
            $grossPay = ($regularHours * $rateAmount) + ($overtimeHours * $rateAmount * $overtimeRate);
        }

        $grossPay = round($grossPay, 2);
        $deductions = round($grossPay * $deductionRate, 2);
        $netPay = round($grossPay - $deductions, 2);

        $workerId = (int) $worker['WorkerID'];
        $insertPayrollStmt->bind_param(
            "issddd",
            $workerId,
            $periodStart,
            $periodEnd,
            $grossPay,
            $deductions,
            $netPay
        );

        if (!$insertPayrollStmt->execute()) {
            throw new Exception('Failed to insert payroll row: ' . $insertPayrollStmt->error);
        }

        if ($firstPayrollId === null) {
            $firstPayrollId = $insertPayrollStmt->insert_id;
        }

        $totalGross += $grossPay;
        $totalDeductions += $deductions;
        $totalNet += $netPay;
        $processedWorkers++;
    }

    $insertPayrollStmt->close();

    $status = 'Processed';
    $recordStmt = $conn->prepare("
        INSERT INTO payroll_records (
            PayrollID,
            SiteID,
            Period_start,
            Period_end,
            Total_gross_pay,
            Total_deductions,
            Total_net_pay,
            Status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$recordStmt) {
        throw new Exception('Failed to prepare payroll record insert: ' . $conn->error);
    }

    $roundedGross = round($totalGross, 2);
    $roundedDeductions = round($totalDeductions, 2);
    $roundedNet = round($totalNet, 2);

    $recordStmt->bind_param(
        "iissddds",
        $firstPayrollId,
        $siteId,
        $periodStart,
        $periodEnd,
        $roundedGross,
        $roundedDeductions,
        $roundedNet,
        $status
    );

    if (!$recordStmt->execute()) {
        throw new Exception('Failed to insert payroll summary: ' . $recordStmt->error);
    }

    $recordId = $recordStmt->insert_id;
    $recordStmt->close();

    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Payroll processed successfully',
        'record_id' => $recordId,
        'site_name' => $site['Site_Name'],
        'workers_processed' => $processedWorkers,
        'summary' => [
            'gross_pay' => $roundedGross,
            'total_deductions' => $roundedDeductions,
            'net_pay' => $roundedNet
        ]
    ]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>
