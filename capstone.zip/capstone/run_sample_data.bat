@echo off
echo Importing sample payroll staff and assignments...
c:\xampp\mysql\bin\mysql.exe -u root payroll_db < "c:\xampp\htdocs\dev1php\htdocs\capstone\database\sample_staff_assign.sql"
if %errorlevel% == 0 (
  echo SUCCESS: Sample data inserted.
) else (
  echo ERROR: Import failed.
)
echo Verifying counts...
c:\xampp\mysql\bin\mysql.exe -u root payroll_db -e "SELECT 'Payroll Staff Count' as metric, COUNT(*) as count FROM payrollstaff UNION SELECT 'Assignments Count' as metric, COUNT(*) as count FROM payrollstaffassignment;"
pause

