const API_BASE = '../api';

let currentStaffId = null;
let currentStaffName = '';
let staffList = [];
let allSites = [];
let assignedSites = [];
let currentUserId = 1;
let searchTerm = '';

function getApiUrl(endpoint) {
    return `${API_BASE}/${endpoint}`;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function showToast(message, type = 'success') {
    document.querySelectorAll('.toast').forEach((toast) => toast.remove());

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${escapeHtml(message)}
    `;

    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function showLoading(element) {
    if (!element) {
        return;
    }
    element.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
}

async function fetchApi(endpoint, options = {}) {
    const response = await fetch(getApiUrl(endpoint), {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        }
    });

    const data = await response.json();
    if (!data.success) {
        throw new Error(data.message || 'API error');
    }

    return data;
}

function getStaffById(staffId) {
    return staffList.find((staff) => Number(staff.id) === Number(staffId)) || null;
}

function updateStatsFromState() {
    const staffCountEl = document.getElementById('staffCount');
    const siteCountEl = document.getElementById('siteCount');
    const assignmentCountEl = document.getElementById('assignmentCount');

    if (staffCountEl) {
        staffCountEl.textContent = staffList.length;
    }
    if (siteCountEl) {
        siteCountEl.textContent = allSites.filter((site) => String(site.Status || '').toLowerCase() === 'active').length;
    }
    if (assignmentCountEl) {
        const totalAssignments = staffList.reduce((total, staff) => total + Number(staff.assigned_sites_count || 0), 0);
        assignmentCountEl.textContent = totalAssignments;
    }
}

async function loadStats() {
    await Promise.all([
        loadStaff(),
        loadAllSites()
    ]);
    updateStatsFromState();
}

async function loadStaff() {
    const data = await fetchApi('get_payroll_staff.php');
    staffList = data.staff || [];
    renderStaffList();
}

async function loadAllSites() {
    const data = await fetchApi('get_active_sites.php');
    allSites = data.sites || data || [];
}

async function loadAssignedSites(staffId) {
    const data = await fetchApi(`get_staff_sites.php?staff_id=${staffId}`);
    assignedSites = data.sites || [];
    renderSites();
    updatePanelHeader();
}

function getFilteredStaff() {
    const term = searchTerm.trim().toLowerCase();
    if (!term) {
        return staffList;
    }

    return staffList.filter((staff) =>
        String(staff.name || '').toLowerCase().includes(term) ||
        String(staff.email || '').toLowerCase().includes(term)
    );
}

function renderStaffList() {
    const container = document.getElementById('staffList');
    if (!container) {
        return;
    }

    const filteredStaff = getFilteredStaff();
    if (filteredStaff.length === 0) {
        container.innerHTML = '<div class="loading">No payroll staff found.</div>';
        return;
    }

    container.innerHTML = filteredStaff.map((staff) => {
        const count = Number(staff.assigned_sites_count || 0);
        return `
            <div class="staff-item${Number(staff.id) === Number(currentStaffId) ? ' selected' : ''}"
                 data-staff-id="${staff.id}"
                 data-staff-name="${escapeHtml(staff.name)}">
                <div class="staff-item-header">
                    <div class="staff-name">${escapeHtml(staff.name)}</div>
                    ${count > 0 ? `<span class="staff-sites-badge">${count} Site${count === 1 ? '' : 's'}</span>` : ''}
                </div>
                <div class="staff-email">${escapeHtml(staff.email || '')}</div>
                ${staff.user_status === 'Inactive' ? '<span class="status-badge inactive">Inactive</span>' : ''}
            </div>
        `;
    }).join('');
}

function updatePanelHeader() {
    const emptyState = document.getElementById('emptyState');
    const sitesContent = document.getElementById('sitesContent');
    const panelTitle = document.getElementById('panelTitle');
    const panelSubtitle = document.getElementById('panelSubtitle');

    if (!currentStaffId) {
        if (emptyState) {
            emptyState.style.display = 'flex';
        }
        if (sitesContent) {
            sitesContent.style.display = 'none';
        }
        return;
    }

    if (emptyState) {
        emptyState.style.display = 'none';
    }
    if (sitesContent) {
        sitesContent.style.display = 'block';
    }
    if (panelTitle) {
        panelTitle.textContent = `Assign Sites to ${currentStaffName}`;
    }
    if (panelSubtitle) {
        panelSubtitle.textContent = `${assignedSites.length} site${assignedSites.length === 1 ? '' : 's'} assigned`;
    }
}

function renderSites() {
    const container = document.getElementById('sitesList');
    if (!container) {
        return;
    }

    if (!currentStaffId) {
        container.innerHTML = '';
        return;
    }

    const assignedSiteIds = new Set(assignedSites.map((site) => Number(site.SiteID)));
    const sortedSites = [...allSites].sort((firstSite, secondSite) => {
        const firstAssigned = assignedSiteIds.has(Number(firstSite.SiteID)) ? 1 : 0;
        const secondAssigned = assignedSiteIds.has(Number(secondSite.SiteID)) ? 1 : 0;

        if (firstAssigned !== secondAssigned) {
            return secondAssigned - firstAssigned;
        }

        return String(firstSite.Site_Name || '').localeCompare(String(secondSite.Site_Name || ''));
    });

    container.innerHTML = sortedSites.map((site) => {
        const isAssigned = assignedSiteIds.has(Number(site.SiteID));
        const statusClass = String(site.Status || '').toLowerCase();

        return `
            <div class="site-item ${statusClass === 'inactive' ? 'inactive' : ''}" data-site="${site.SiteID}">
                <div class="site-item-header">
                    <div>
                        <div class="site-name">${escapeHtml(site.Site_Name)}</div>
                        <div class="site-address">${escapeHtml(site.Location || '')}</div>
                    </div>
                    <button class="site-action ${isAssigned ? 'remove' : 'add'}"
                            type="button"
                            data-site-id="${site.SiteID}">
                        <i class="fas ${isAssigned ? 'fa-trash' : 'fa-plus'}"></i>
                    </button>
                </div>
                <span class="site-status ${statusClass}">${escapeHtml(site.Status || 'Unknown')}</span>
                <div class="site-details">
                    <div>${site.current_workers || 0} Current Workers</div>
                    <div>Required: ${site.Required_Workers || 'N/A'}</div>
                </div>
            </div>
        `;
    }).join('');
}

async function selectStaff(staffId, staffName = '') {
    currentStaffId = Number(staffId);
    currentStaffName = staffName || getStaffById(staffId)?.name || 'Staff';

    renderStaffList();
    updatePanelHeader();
    showLoading(document.getElementById('sitesList'));

    try {
        await loadAssignedSites(currentStaffId);
    } catch (error) {
        console.error('Failed to load assigned sites:', error);
        showToast(error.message || 'Failed to load assigned sites', 'error');
    }
}

function updateLocalAssignmentCounts(staffId, delta) {
    const staff = getStaffById(staffId);
    if (!staff) {
        return;
    }

    staff.assigned_sites_count = Math.max(0, Number(staff.assigned_sites_count || 0) + delta);
}

async function assignSite(staffId, siteId) {
    const numericStaffId = Number(staffId);
    const numericSiteId = Number(siteId);
    showLoading(document.getElementById('sitesList'));

    try {
        await fetchApi('assign_site_to_staff.php', {
            method: 'POST',
            body: JSON.stringify({
                staff_id: numericStaffId,
                site_id: numericSiteId,
                user_id: currentUserId
            })
        });

        const assignedSite = allSites.find((site) => Number(site.SiteID) === numericSiteId);
        if (assignedSite && !assignedSites.some((site) => Number(site.SiteID) === numericSiteId)) {
            assignedSites.push({
                ...assignedSite,
                SiteID: numericSiteId
            });
        }

        updateLocalAssignmentCounts(numericStaffId, 1);
        updateStatsFromState();
        renderStaffList();
        renderSites();
        updatePanelHeader();
        showToast('Site assigned successfully!');
    } catch (error) {
        console.error('Assign site failed:', error);
        await loadAssignedSites(numericStaffId).catch(() => {});
        showToast(error.message || 'Failed to assign site', 'error');
    }
}

async function removeSite(staffId, siteId) {
    const numericStaffId = Number(staffId);
    const numericSiteId = Number(siteId);

    if (!confirm('Remove this site assignment?')) {
        return;
    }

    showLoading(document.getElementById('sitesList'));

    try {
        await fetchApi('remove_site_assignment.php', {
            method: 'POST',
            body: JSON.stringify({
                staff_id: numericStaffId,
                site_id: numericSiteId,
                user_id: currentUserId
            })
        });

        assignedSites = assignedSites.filter((site) => Number(site.SiteID) !== numericSiteId);
        updateLocalAssignmentCounts(numericStaffId, -1);
        updateStatsFromState();
        renderStaffList();
        renderSites();
        updatePanelHeader();
        showToast('Site assignment removed!');
    } catch (error) {
        console.error('Remove site failed:', error);
        await loadAssignedSites(numericStaffId).catch(() => {});
        showToast(error.message || 'Failed to remove assignment', 'error');
    }
}

async function viewAuditLog() {
    try {
        const data = await fetchApi('get_audit_logs.php?type=assignment');
        renderAuditModal(Array.isArray(data) ? data : data.logs || []);
    } catch (error) {
        showToast('Failed to load audit logs', 'error');
    }
}

function renderAuditModal(logs) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-clipboard-list"></i> Audit Logs (Assignments)</h3>
                <button class="modal-close" type="button">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="audit-table">
                    ${logs.map((log) => `
                        <div class="audit-row">
                            <div class="audit-user">${escapeHtml(log.user || '')}</div>
                            <div class="audit-action">${escapeHtml(log.action || '')}</div>
                            <div class="audit-time">${escapeHtml(log.ts ? new Date(log.ts).toLocaleString() : '')}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    modal.querySelector('.modal-close')?.addEventListener('click', () => modal.remove());
    document.body.appendChild(modal);
}

function handleStaffClick(event) {
    const staffItem = event.target.closest('.staff-item');
    if (!staffItem) {
        return;
    }

    selectStaff(staffItem.dataset.staffId, staffItem.dataset.staffName);
}

function handleSiteAction(event) {
    const button = event.target.closest('.site-action');
    if (!button || !currentStaffId) {
        return;
    }

    const siteId = Number(button.dataset.siteId);
    const isAssigned = assignedSites.some((site) => Number(site.SiteID) === siteId);

    if (isAssigned) {
        removeSite(currentStaffId, siteId);
    } else {
        assignSite(currentStaffId, siteId);
    }
}

function filterStaff() {
    searchTerm = document.getElementById('staffSearch')?.value || '';
    renderStaffList();
}

document.addEventListener('DOMContentLoaded', async () => {
    currentUserId = Number(document.getElementById('currentUserId')?.value || 1);

    try {
        showLoading(document.querySelector('.staff-list'));
        await loadStats();
        updatePanelHeader();
    } catch (error) {
        console.error('Failed to initialize dashboard:', error);
        showToast(error.message || 'Failed to initialize dashboard', 'error');
    }

    document.getElementById('staffSearch')?.addEventListener('input', filterStaff);
    document.getElementById('staffList')?.addEventListener('click', handleStaffClick);
    document.getElementById('sitesList')?.addEventListener('click', handleSiteAction);
});

window.selectStaff = selectStaff;
window.assignSite = assignSite;
window.removeSite = removeSite;
window.viewAuditLog = viewAuditLog;
window.filterStaff = filterStaff;
