const API_BASE = '../api/';
let currentUserId = 1;

const assignmentState = {
    workers: [],
    sites: [],
    selectedWorkerId: null,
    workerAssignments: new Map(),
    loadedWorkers: new Set(),
    searchTerm: '',
    dragWorkerId: null
};

function updateDateTime() {
    const now = new Date();
    const dateEl = document.getElementById('currentDate');
    const timeEl = document.getElementById('currentTime');
    if (!dateEl || !timeEl) {
        return;
    }

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;

    dateEl.textContent = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    timeEl.textContent = `${hours}:${minutes} ${ampm}`;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function formatCurrency(value) {
    return `PHP ${parseFloat(value || 0).toLocaleString('en-PH', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
}

function getStatusClass(status) {
    switch (status) {
        case 'Active':
            return 'active';
        case 'Inactive':
            return 'inactive';
        case 'OnLeave':
            return 'on-leave';
        default:
            return 'active';
    }
}

async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    return response.json();
}

function showAssignmentFeedback(message, type = 'success') {
    const feedbackEl = document.getElementById('assignmentFeedback');
    if (!feedbackEl) {
        alert(message);
        return;
    }

    feedbackEl.className = `assignment-feedback show ${type}`;
    feedbackEl.textContent = message;

    clearTimeout(showAssignmentFeedback.timeoutId);
    showAssignmentFeedback.timeoutId = setTimeout(() => {
        feedbackEl.className = 'assignment-feedback';
        feedbackEl.textContent = '';
    }, 3000);
}

function renderEmployeeTable(employees) {
    const tbody = document.getElementById('employeeTableBody');
    if (!tbody) {
        return;
    }

    if (!employees || employees.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align:center; padding:20px;">
                    No employees found. Click "Add New Employee" to create one.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = employees.map((employee) => {
        const fullName = employee.full_name || `${employee.First_Name || ''} ${employee.Last_Name || ''}`.trim();
        const initial = (employee.First_Name || fullName || 'E').charAt(0).toUpperCase();

        return `
            <tr>
                <td>
                    <div class="employee-info">
                        <div class="employee-avatar">${escapeHtml(initial)}</div>
                        <div class="employee-details">
                            <div class="employee-name">${escapeHtml(fullName)}</div>
                            <div class="employee-id">ID: ${employee.WorkerID}</div>
                        </div>
                    </div>
                </td>
                <td>${escapeHtml(employee.position || 'Not Assigned')}</td>
                <td>${escapeHtml(employee.Site_Name || 'Not Assigned')}</td>
                <td><span class="status-badge ${getStatusClass(employee.worker_status)}">${escapeHtml(employee.worker_status || 'Active')}</span></td>
                <td class="salary">${formatCurrency(employee.salary)}</td>
                <td>${escapeHtml(employee.join_date || 'N/A')}</td>
                <td>
                    <div class="approval-info">
                        <span class="approval-badge">Pending</span>
                        <span class="approval-by">Not approved</span>
                    </div>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-action view" title="View">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-action delete" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

async function loadEmployees() {
    try {
        const data = await fetchJson(`${API_BASE}get_employees.php`);
        if (data.success) {
            renderEmployeeTable(data.employees);
        }
    } catch (error) {
        console.error('Error loading employees:', error);
    }
}

async function searchEmployees(term) {
    try {
        if (!term) {
            await loadEmployees();
            return;
        }

        const data = await fetchJson(`${API_BASE}search_employees.php?search=${encodeURIComponent(term)}`);
        if (data.success) {
            renderEmployeeTable(data.employees);
        }
    } catch (error) {
        console.error('Search failed:', error);
    }
}

async function filterBySite(siteId) {
    try {
        if (!siteId) {
            await loadEmployees();
            return;
        }

        const data = await fetchJson(`${API_BASE}filter_employees_by_site.php?site_id=${encodeURIComponent(siteId)}`);
        if (data.success) {
            renderEmployeeTable(data.employees);
        }
    } catch (error) {
        console.error('Site filter failed:', error);
    }
}

async function filterByStatus(status) {
    try {
        if (!status) {
            await loadEmployees();
            return;
        }

        const data = await fetchJson(`${API_BASE}filter_employees_by_status.php?status=${encodeURIComponent(status)}`);
        if (data.success) {
            renderEmployeeTable(data.employees);
        }
    } catch (error) {
        console.error('Status filter failed:', error);
    }
}

async function viewEmployee(id) {
    try {
        const data = await fetchJson(`${API_BASE}get_employee.php?id=${id}`);
        if (!data.success) {
            alert(`Failed: ${data.message}`);
            return;
        }

        const emp = data.employee;
        alert(
            `Name: ${emp.full_name}\n` +
            `Position: ${emp.position || 'N/A'}\n` +
            `Site: ${emp.Site_Name || 'N/A'}\n` +
            `Status: ${emp.worker_status || 'Active'}\n` +
            `Salary: ${formatCurrency(emp.salary)}\n` +
            `Join: ${emp.join_date || 'N/A'}\n` +
            `Phone: ${emp.phone || 'N/A'}`
        );
    } catch (error) {
        console.error('View employee failed:', error);
    }
}

async function deleteEmployee(id) {
    if (!confirm('Delete this employee?')) {
        return;
    }

    try {
        const data = await fetchJson(`${API_BASE}delete_employee.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, user_id: currentUserId })
        });

        if (!data.success) {
            alert(`Failed: ${data.message}`);
            return;
        }

        alert('Employee deleted successfully.');
        location.reload();
    } catch (error) {
        console.error('Delete employee failed:', error);
    }
}

function initializeAssignmentState() {
    const initialData = window.employeeAssignmentData || {};

    assignmentState.workers = Array.isArray(initialData.workers) ? initialData.workers.map((worker) => ({
        WorkerID: Number(worker.WorkerID),
        full_name: worker.full_name || 'Unknown Worker',
        phone: worker.phone || '',
        assigned_sites_count: Number(worker.assigned_sites_count || 0)
    })) : [];

    assignmentState.sites = Array.isArray(initialData.sites) ? initialData.sites.map((site) => ({
        SiteID: Number(site.SiteID),
        Site_Name: site.Site_Name || 'Unnamed Site',
        Location: site.Location || 'No location',
        Status: site.Status || 'Inactive',
        Required_Workers: Number(site.Required_Workers || 0),
        current_workers: Number(site.current_workers || 0)
    })) : [];

    assignmentState.selectedWorkerId = null;

    if (assignmentState.workers.length === 0) {
        assignmentState.workers = Array.from(document.querySelectorAll('#staffList .staff-item[data-worker-id], #staffList .staff-item[data-staff]')).map((item) => {
            const workerId = Number(item.dataset.workerId || item.dataset.staff);
            const name = item.querySelector('.staff-name')?.textContent?.trim() || 'Unknown Worker';
            const detailText = item.querySelector('.staff-email')?.textContent?.trim() || '';
            const badgeText = item.querySelector('.staff-sites-badge')?.textContent?.trim() || '0';
            const badgeMatch = badgeText.match(/\d+/);

            return {
                WorkerID: workerId,
                full_name: name,
                phone: detailText.replace(/^ID:\s*\d+\s*[.\-|·]\s*/u, ''),
                assigned_sites_count: badgeMatch ? Number(badgeMatch[0]) : 0
            };
        }).filter((worker) => worker.WorkerID);
    }

    const assignmentsEl = document.getElementById('assignmentsCount');
    if (assignmentsEl && typeof initialData.assignmentCount !== 'undefined') {
        assignmentsEl.textContent = initialData.assignmentCount;
    }
}

function getWorkerById(workerId) {
    return assignmentState.workers.find((worker) => worker.WorkerID === Number(workerId)) || null;
}

function getSiteById(siteId) {
    return assignmentState.sites.find((site) => site.SiteID === Number(siteId)) || null;
}

function getAssignedSiteIds(workerId) {
    return assignmentState.workerAssignments.get(Number(workerId)) || new Set();
}

function setAssignedSiteIds(workerId, siteIds) {
    assignmentState.workerAssignments.set(Number(workerId), new Set(siteIds.map((siteId) => Number(siteId))));
    assignmentState.loadedWorkers.add(Number(workerId));
}

function getSelectedWorker() {
    return getWorkerById(assignmentState.selectedWorkerId);
}

function getFilteredWorkers() {
    const term = assignmentState.searchTerm.trim().toLowerCase();
    if (!term) {
        return assignmentState.workers;
    }

    return assignmentState.workers.filter((worker) => (
        worker.full_name.toLowerCase().includes(term) ||
        String(worker.WorkerID).includes(term)
    ));
}

function loadDashboardStats() {
    const staffCountEl = document.getElementById('staffCount');
    const activeSitesEl = document.getElementById('activeSitesCount');

    if (staffCountEl) {
        staffCountEl.textContent = assignmentState.workers.length;
    }
    if (activeSitesEl) {
        activeSitesEl.textContent = assignmentState.sites.filter((site) => String(site.Status).toLowerCase() === 'active').length;
    }
}

function renderStaffList() {
    const container = document.getElementById('staffList');
    if (!container) {
        return;
    }

    const filteredWorkers = getFilteredWorkers();
    if (filteredWorkers.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-title">No workers found</div>
                <div class="empty-state-text">Try another name or worker ID.</div>
            </div>
        `;
        return;
    }

    container.innerHTML = filteredWorkers.map((worker) => {
        const assignedCount = Number(worker.assigned_sites_count || 0);
        const isSelected = worker.WorkerID === assignmentState.selectedWorkerId;

        return `
            <div class="staff-item${isSelected ? ' selected' : ''}"
                 data-staff="${worker.WorkerID}"
                 data-worker-id="${worker.WorkerID}"
                 draggable="true">
                <div class="staff-item-header">
                    <div class="staff-name">${escapeHtml(worker.full_name)}</div>
                    <span class="staff-sites-badge${assignedCount > 0 ? '' : ' hidden'}">
                        ${assignedCount} Site${assignedCount === 1 ? '' : 's'}
                    </span>
                </div>
                <div class="staff-email">ID: ${worker.WorkerID} | ${escapeHtml(worker.phone || 'No phone')}</div>
            </div>
        `;
    }).join('');
}

function updatePanelCopy() {
    const selectedWorker = getSelectedWorker();
    const panelTitle = document.getElementById('panelTitle');
    const panelSubtitle = document.getElementById('panelSubtitle');
    const selectedWorkerName = document.getElementById('selectedWorkerName');
    const selectedWorkerSites = document.getElementById('selectedWorkerSites');
    const emptyState = document.getElementById('emptyState');
    const sitesContent = document.getElementById('sitesContent');

    if (!selectedWorker) {
        if (emptyState) {
            emptyState.style.display = 'flex';
        }
        if (sitesContent) {
            sitesContent.style.display = 'none';
        }
        if (panelTitle) {
            panelTitle.textContent = 'Assign Sites to Worker';
        }
        if (panelSubtitle) {
            panelSubtitle.textContent = `${assignmentState.sites.length} sites available`;
        }
        if (selectedWorkerName) {
            selectedWorkerName.textContent = 'No worker selected';
        }
        if (selectedWorkerSites) {
            selectedWorkerSites.innerHTML = '';
        }
        return;
    }

    if (emptyState) {
        emptyState.style.display = 'none';
    }
    if (sitesContent) {
        sitesContent.style.display = 'block';
    }

    const assignedSiteIds = getAssignedSiteIds(selectedWorker.WorkerID);
    const assignedCount = assignedSiteIds.size || Number(selectedWorker.assigned_sites_count || 0);
    const assignedSiteNames = assignmentState.sites
        .filter((site) => assignedSiteIds.has(site.SiteID))
        .map((site) => escapeHtml(site.Site_Name));

    if (panelTitle) {
        panelTitle.textContent = `Assign Sites to ${selectedWorker.full_name}`;
    }
    if (panelSubtitle) {
        panelSubtitle.textContent = `${assignedCount} assigned site${assignedCount === 1 ? '' : 's'} | ${assignmentState.sites.length} total site${assignmentState.sites.length === 1 ? '' : 's'}`;
    }
    if (selectedWorkerName) {
        selectedWorkerName.textContent = `${selectedWorker.full_name} (ID: ${selectedWorker.WorkerID})`;
    }
    if (selectedWorkerSites) {
        selectedWorkerSites.innerHTML = assignedSiteNames.length > 0
            ? assignedSiteNames.map((siteName) => `<span class="assigned-site-pill">${siteName}</span>`).join('')
            : '<span class="assigned-site-pill assigned-site-pill--empty">No assigned sites yet</span>';
    }
}

function renderSites(loading = false) {
    const container = document.getElementById('sitesList');
    if (!container) {
        return;
    }

    if (loading) {
        container.innerHTML = `
            <div class="site-empty-state">
                <i class="fas fa-spinner fa-spin"></i>
                <div class="site-empty-state__title">Loading assignments</div>
            </div>
        `;
        return;
    }

    if (assignmentState.sites.length === 0) {
        container.innerHTML = `
            <div class="site-empty-state">
                <i class="fas fa-map-marker-alt"></i>
                <div class="site-empty-state__title">No sites available</div>
                <div class="site-empty-state__text">Create a site first to start assigning workers.</div>
            </div>
        `;
        return;
    }

    const selectedWorker = getSelectedWorker();
    if (!selectedWorker) {
        container.innerHTML = '';
        return;
    }

    const assignedSiteIds = getAssignedSiteIds(selectedWorker.WorkerID);
    const sortedSites = [...assignmentState.sites].sort((a, b) => {
        const aAssigned = assignedSiteIds.has(a.SiteID) ? 1 : 0;
        const bAssigned = assignedSiteIds.has(b.SiteID) ? 1 : 0;
        if (aAssigned !== bAssigned) {
            return bAssigned - aAssigned;
        }
        return String(a.Site_Name).localeCompare(String(b.Site_Name));
    });

    container.innerHTML = sortedSites.map((site) => {
        const isAssigned = assignedSiteIds.has(site.SiteID);
        const isInactive = String(site.Status).toLowerCase() === 'inactive';
        const target = Number(site.Required_Workers || 0);
        const current = Number(site.current_workers || 0);
        const atCapacity = target > 0 && current >= target;

        return `
            <div class="site-item${isInactive ? ' inactive' : ''}${isAssigned ? ' assigned' : ''}${atCapacity ? ' at-capacity' : ''}"
                 data-site-id="${site.SiteID}">
                <div class="site-item-header">
                    <div>
                        <div class="site-name">${escapeHtml(site.Site_Name)}</div>
                        <div class="site-address">${escapeHtml(site.Location || 'No location')}</div>
                    </div>
                    <button class="site-action ${isAssigned ? 'remove' : 'add'}"
                            type="button"
                            data-site-id="${site.SiteID}"
                            aria-label="${isAssigned ? 'Remove assignment' : 'Assign worker'}"
                            ${isInactive ? 'disabled' : ''}>
                        <i class="fas ${isAssigned ? 'fa-minus' : 'fa-plus'}"></i>
                    </button>
                </div>
                <span class="site-status ${String(site.Status).toLowerCase()}">${escapeHtml(site.Status)}</span>
                <div class="site-details">
                    <div class="site-detail-item">
                        <span><span class="site-current-count">${current}</span> Current Workers</span>
                    </div>
                    <div class="site-detail-item">
                        <span>Target: <span class="site-target-count">${target}</span></span>
                    </div>
                </div>
                <div class="site-assignment-state">
                    <span class="site-assignment-label">${isAssigned ? 'Assigned to selected worker' : 'Available for assignment'}</span>
                    ${atCapacity ? '<span class="site-capacity-warning">Target reached</span>' : ''}
                </div>
                ${isAssigned ? '<div class="site-assignment-note">This worker is currently assigned here.</div>' : ''}
                <div class="site-drop-hint">Drop a worker here to assign</div>
            </div>
        `;
    }).join('');
}

function updateAssignmentsOverview(delta) {
    const assignmentsEl = document.getElementById('assignmentsCount');
    if (!assignmentsEl) {
        return;
    }

    assignmentsEl.textContent = Math.max(0, Number(assignmentsEl.textContent || 0) + delta);
}

function updateWorkerAssignmentCount(workerId, delta) {
    const worker = getWorkerById(workerId);
    if (!worker) {
        return;
    }
    worker.assigned_sites_count = Math.max(0, Number(worker.assigned_sites_count || 0) + delta);
}

function updateSiteWorkerCount(siteId, delta) {
    const site = getSiteById(siteId);
    if (!site) {
        return;
    }
    site.current_workers = Math.max(0, Number(site.current_workers || 0) + delta);
}

async function refreshSiteWorkerCount(siteId) {
    const numericSiteId = Number(siteId);
    if (!numericSiteId) {
        return;
    }

    try {
        const data = await fetchJson(`${API_BASE}get_site_worker_count.php?site_id=${numericSiteId}`);
        if (!data.success) {
            return;
        }

        const site = getSiteById(numericSiteId);
        if (!site) {
            return;
        }

        site.current_workers = Number(data.current_workers || 0);
        if (data.site) {
            site.Required_Workers = Number(data.site.Required_Workers || site.Required_Workers || 0);
            site.Status = data.site.Status || site.Status;
            site.Location = data.site.Location || site.Location;
            site.Site_Name = data.site.Site_Name || site.Site_Name;
        }
    } catch (error) {
        console.error('Failed to refresh site worker count:', error);
    }
}

async function loadWorkerAssignments(workerId, forceRefresh = false) {
    const numericWorkerId = Number(workerId);
    if (!numericWorkerId) {
        return;
    }

    if (assignmentState.loadedWorkers.has(numericWorkerId) && !forceRefresh) {
        return;
    }

    const data = await fetchJson(`${API_BASE}get_worker_sites.php?worker_id=${numericWorkerId}`);
    if (!data.success) {
        throw new Error(data.message || 'Failed to load worker assignments.');
    }

    const siteIds = (data.sites || []).map((site) => Number(site.SiteID));
    setAssignedSiteIds(numericWorkerId, siteIds);

    (data.sites || []).forEach((assignedSite) => {
        const localSite = getSiteById(assignedSite.SiteID);
        if (localSite) {
            localSite.current_workers = Number(assignedSite.current_workers || localSite.current_workers || 0);
        }
    });
}

async function selectStaff(workerId) {
    const numericWorkerId = Number(workerId);
    if (!numericWorkerId) {
        return;
    }

    assignmentState.selectedWorkerId = numericWorkerId;
    renderStaffList();
    updatePanelCopy();
    renderSites(true);

    try {
        await loadWorkerAssignments(numericWorkerId);
        renderSites();
        updatePanelCopy();
    } catch (error) {
        console.error('Failed to load worker assignments:', error);
        renderSites();
        showAssignmentFeedback(error.message || 'Unable to load assignments.', 'error');
    }
}

async function assignSiteToStaff(siteId, workerId = null) {
    const numericSiteId = Number(siteId);
    const numericWorkerId = Number(workerId || assignmentState.selectedWorkerId);

    if (!numericWorkerId) {
        showAssignmentFeedback('Select a worker first.', 'error');
        return;
    }

    const site = getSiteById(numericSiteId);
    if (!site) {
        showAssignmentFeedback('Site not found.', 'error');
        return;
    }

    if (String(site.Status).toLowerCase() === 'inactive') {
        showAssignmentFeedback('Inactive sites cannot receive assignments.', 'error');
        return;
    }

    await loadWorkerAssignments(numericWorkerId);
    const assignedSiteIds = getAssignedSiteIds(numericWorkerId);
    if (assignedSiteIds.has(numericSiteId)) {
        showAssignmentFeedback('This worker is already assigned to that site.', 'error');
        return;
    }

    try {
        const data = await fetchJson(`${API_BASE}assign_worker.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ workerId: numericWorkerId, siteId: numericSiteId })
        });

        if (!data.success) {
            throw new Error(data.message || 'Assignment failed.');
        }

        assignedSiteIds.add(numericSiteId);
        assignmentState.workerAssignments.set(numericWorkerId, assignedSiteIds);
        assignmentState.selectedWorkerId = numericWorkerId;
        updateWorkerAssignmentCount(numericWorkerId, 1);
        updateAssignmentsOverview(1);
        await refreshSiteWorkerCount(numericSiteId);

        renderStaffList();
        renderSites();
        updatePanelCopy();

        const updatedSite = getSiteById(numericSiteId);
        if (updatedSite && updatedSite.Required_Workers > 0 && updatedSite.current_workers >= updatedSite.Required_Workers) {
            showAssignmentFeedback(`Assigned successfully. ${updatedSite.Site_Name} has reached its target capacity.`, 'warning');
        } else {
            showAssignmentFeedback('Worker assigned successfully.');
        }
    } catch (error) {
        console.error('Assignment failed:', error);
        showAssignmentFeedback(error.message || 'Failed to assign worker.', 'error');
    }
}

async function removeSiteAssignment(siteId, workerId = null) {
    const numericSiteId = Number(siteId);
    const numericWorkerId = Number(workerId || assignmentState.selectedWorkerId);
    if (!numericWorkerId || !numericSiteId) {
        showAssignmentFeedback('Worker and site are required.', 'error');
        return;
    }

    if (!confirm('Remove this worker from the selected site?')) {
        return;
    }

    try {
        const data = await fetchJson(`${API_BASE}remove_worker_assignment.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                worker_id: numericWorkerId,
                site_id: numericSiteId,
                user_id: currentUserId
            })
        });

        if (!data.success) {
            throw new Error(data.message || 'Removal failed.');
        }

        const assignedSiteIds = getAssignedSiteIds(numericWorkerId);
        assignedSiteIds.delete(numericSiteId);
        assignmentState.workerAssignments.set(numericWorkerId, assignedSiteIds);
        updateWorkerAssignmentCount(numericWorkerId, -1);
        updateAssignmentsOverview(-1);
        await refreshSiteWorkerCount(numericSiteId);

        renderStaffList();
        renderSites();
        updatePanelCopy();
        showAssignmentFeedback('Worker removed from site.');
    } catch (error) {
        console.error('Removal failed:', error);
        showAssignmentFeedback(error.message || 'Failed to remove assignment.', 'error');
    }
}

function showAddEmployeeModal() {
    const modal = document.getElementById('addEmployeeModal');
    if (!modal) {
        return;
    }
    modal.classList.add('active');
    document.getElementById('addEmployeeForm')?.reset();
}

function closeModal() {
    document.getElementById('addEmployeeModal')?.classList.remove('active');
}

async function handleAddEmployeeSubmit(event) {
    event.preventDefault();

    const formData = new FormData(event.target);
    formData.append('user_id', currentUserId);

    try {
        const response = await fetch(`${API_BASE}create_employee.php`, {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (!result.success) {
            alert(`Error: ${result.message}`);
            return;
        }

        alert('Employee added successfully.');
        closeModal();
        await loadEmployees();
    } catch (error) {
        console.error('Submit error:', error);
        alert('Network error. Please try again.');
    }
}

function handleStaffListClick(event) {
    const staffItem = event.target.closest('.staff-item');
    if (!staffItem) {
        return;
    }
    selectStaff(staffItem.dataset.workerId || staffItem.dataset.staff);
}

function handleStaffDragStart(event) {
    const staffItem = event.target.closest('.staff-item');
    if (!staffItem) {
        return;
    }
    assignmentState.dragWorkerId = Number(staffItem.dataset.workerId || staffItem.dataset.staff);
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', String(assignmentState.dragWorkerId));
}

function handleSitesClick(event) {
    const button = event.target.closest('.site-action');
    if (!button) {
        return;
    }

    const siteId = Number(button.dataset.siteId);
    if (button.classList.contains('remove')) {
        removeSiteAssignment(siteId);
    } else {
        assignSiteToStaff(siteId);
    }
}

function handleSiteDragOver(event) {
    const siteItem = event.target.closest('.site-item');
    if (!siteItem) {
        return;
    }
    event.preventDefault();
    siteItem.classList.add('drag-over');
}

function handleSiteDragLeave(event) {
    const siteItem = event.target.closest('.site-item');
    if (!siteItem) {
        return;
    }
    siteItem.classList.remove('drag-over');
}

function handleSiteDrop(event) {
    const siteItem = event.target.closest('.site-item');
    if (!siteItem) {
        return;
    }

    event.preventDefault();
    siteItem.classList.remove('drag-over');

    const workerId = Number(event.dataTransfer.getData('text/plain') || assignmentState.dragWorkerId);
    const siteId = Number(siteItem.dataset.siteId);
    if (workerId && siteId) {
        assignSiteToStaff(siteId, workerId);
    }
}

function bindAssignmentListeners() {
    document.getElementById('staffSearch')?.addEventListener('input', (event) => {
        assignmentState.searchTerm = event.target.value || '';
        renderStaffList();
    });

    document.getElementById('staffList')?.addEventListener('click', handleStaffListClick);
    document.getElementById('staffList')?.addEventListener('dragstart', handleStaffDragStart);

    const sitesList = document.getElementById('sitesList');
    sitesList?.addEventListener('click', handleSitesClick);
    sitesList?.addEventListener('dragover', handleSiteDragOver);
    sitesList?.addEventListener('dragleave', handleSiteDragLeave);
    sitesList?.addEventListener('drop', handleSiteDrop);
}

function bindTabListeners() {
    document.querySelectorAll('.tab').forEach((tab) => {
        tab.addEventListener('click', async function () {
            const tabName = this.dataset.tab;

            document.querySelectorAll('.tab').forEach((item) => item.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.tab-content').forEach((content) => content.classList.remove('active'));

            if (tabName === 'employees') {
                document.getElementById('employeesTab')?.classList.add('active');
                document.getElementById('btnAddEmployee')?.style.setProperty('display', 'flex');
                await loadEmployees();
                return;
            }

            document.getElementById('assignmentsTab')?.classList.add('active');
            document.getElementById('btnAddEmployee')?.style.setProperty('display', 'none');
            loadDashboardStats();
            updatePanelCopy();
            renderSites();
        });
    });
}

function bindModalListeners() {
    document.getElementById('btnAddEmployee')?.addEventListener('click', (event) => {
        event.preventDefault();
        showAddEmployeeModal();
    });

    document.querySelector('.close-modal')?.addEventListener('click', closeModal);
    document.getElementById('addEmployeeModal')?.addEventListener('click', (event) => {
        if (event.target === event.currentTarget) {
            closeModal();
        }
    });
    document.getElementById('addEmployeeForm')?.addEventListener('submit', handleAddEmployeeSubmit);
}

function bindEmployeeTableActions() {
    document.addEventListener('click', (event) => {
        const button = event.target.closest('.btn-action');
        if (!button) {
            return;
        }

        const row = button.closest('tr');
        const text = row?.querySelector('.employee-id')?.textContent || '';
        const match = text.match(/ID:\s*(\d+)/);
        if (!match) {
            return;
        }

        const employeeId = Number(match[1]);
        if (button.classList.contains('view')) {
            viewEmployee(employeeId);
        } else if (button.classList.contains('delete')) {
            deleteEmployee(employeeId);
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    currentUserId = Number(document.getElementById('currentUserId')?.value || 1);

    updateDateTime();
    setInterval(updateDateTime, 60000);

    bindTabListeners();
    bindModalListeners();
    bindEmployeeTableActions();

    initializeAssignmentState();
    bindAssignmentListeners();
    renderStaffList();
    loadDashboardStats();
    updatePanelCopy();
    renderSites();
    await loadEmployees();
});

window.searchEmployees = searchEmployees;
window.filterBySite = filterBySite;
window.filterByStatus = filterByStatus;
window.viewEmployee = viewEmployee;
window.deleteEmployee = deleteEmployee;
window.selectStaff = selectStaff;
window.assignSiteToStaff = assignSiteToStaff;
window.removeSiteAssignment = removeSiteAssignment;
