function updateDateTime() {
    const dateEl = document.getElementById('currentDate');
    const timeEl = document.getElementById('currentTime');
    if (!dateEl || !timeEl) {
        return;
    }

    const now = new Date();
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;

    dateEl.textContent = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    timeEl.textContent = `${hours}:${minutes} ${ampm}`;
}

const payrollState = {
    sites: [],
    summary: null,
    period: null,
    selectedSiteId: null
};

function formatCurrency(value) {
    return `PHP ${Number(value || 0).toLocaleString('en-PH', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
}

function getSelectedSite() {
    return payrollState.sites.find((site) => Number(site.SiteID) === Number(payrollState.selectedSiteId)) || null;
}

function renderSiteCards() {
    const container = document.getElementById('payrollSitesContainer');
    if (!container) {
        return;
    }

    if (!Array.isArray(payrollState.sites) || payrollState.sites.length === 0) {
        container.innerHTML = `
            <div class="site-card">
                <div class="site-card-title">No sites available</div>
                <div class="site-info-item">Create site assignments to begin payroll processing.</div>
            </div>
        `;
        return;
    }

    container.innerHTML = payrollState.sites.map((site) => `
        <div class="site-card">
            <div class="site-card-header">
                <div class="site-card-icon">
                    <i class="fas fa-building"></i>
                </div>
                <span class="site-status-badge">${site.processed ? 'Processed' : 'Ready'}</span>
            </div>
            <div class="site-card-title">${site.Site_Name}</div>
            <div class="site-info">
                <div class="site-info-item"><strong>Location:</strong> ${site.Location || 'No location'}</div>
                <div class="site-info-item"><strong>Workers:</strong> ${site.assigned_workers}</div>
                <div class="site-info-item"><strong>Period:</strong> ${site.period_label}</div>
                <div class="site-info-item"><strong>Gross Pay:</strong> ${formatCurrency(site.gross_pay)}</div>
                <div class="site-info-item"><strong>Net Pay:</strong> ${formatCurrency(site.net_pay)}</div>
            </div>
            <button class="btn-view-details" type="button" data-site-id="${site.SiteID}">
                View Payroll Details
            </button>
        </div>
    `).join('');
}

function renderPayrollDetails() {
    const site = getSelectedSite();
    if (!site) {
        return;
    }

    document.getElementById('siteNameHeader').textContent = site.Site_Name;
    document.getElementById('sitePeriodHeader').textContent = payrollState.period?.label || site.period_label;
    document.getElementById('workersSectionTitle').textContent = `Workers Assigned to ${site.Site_Name}`;
    document.getElementById('processPayrollText').textContent = site.processed
        ? `Payroll for ${site.Site_Name} has already been processed for ${site.period_label}.`
        : `Process payroll for ${site.Site_Name} for ${site.period_label}.`;

    document.getElementById('grossPayValue').textContent = formatCurrency(site.gross_pay);
    document.getElementById('deductionsValue').textContent = formatCurrency(site.deductions);
    document.getElementById('netPayValue').textContent = formatCurrency(site.net_pay);

    const processBtn = document.getElementById('btnProcessPayroll');
    if (processBtn) {
        processBtn.disabled = !!site.processed;
        processBtn.style.opacity = site.processed ? '0.6' : '1';
    }

    const tbody = document.getElementById('payrollTableBody');
    if (!tbody) {
        return;
    }

    if (!site.workers || site.workers.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align:center;">No workers assigned to this site.</td>
            </tr>
        `;
        return;
    }

    let totalGross = 0;
    let totalDeductions = 0;
    let totalNet = 0;

    tbody.innerHTML = site.workers.map((worker) => {
        totalGross += Number(worker.gross_pay || 0);
        totalDeductions += Number(worker.deductions || 0);
        totalNet += Number(worker.net_pay || 0);

        return `
            <tr>
                <td>
                    <div class="employee-info">
                        <div class="employee-name">${worker.full_name}</div>
                        <div class="employee-id">ID: ${worker.WorkerID} | ${worker.rate_type} @ ${formatCurrency(worker.rate_amount)}</div>
                    </div>
                </td>
                <td>
                    <div class="attendance-info">
                        <div class="attendance-days">${worker.attendance_days} day(s)</div>
                        <div class="attendance-details">Present: ${worker.present_days} | Late: ${worker.late_days}</div>
                    </div>
                </td>
                <td>${worker.total_hours} hrs<br><small>OT: ${worker.overtime_hours} hrs</small></td>
                <td class="amount">${formatCurrency(worker.gross_pay)}</td>
                <td class="amount negative">${formatCurrency(worker.deductions)}</td>
                <td class="amount">${formatCurrency(worker.net_pay)}</td>
            </tr>
        `;
    }).join('') + `
        <tr class="table-total-row">
            <td colspan="3">Totals</td>
            <td>${formatCurrency(totalGross)}</td>
            <td>${formatCurrency(totalDeductions)}</td>
            <td>${formatCurrency(totalNet)}</td>
        </tr>
    `;
}

function viewPayrollDetails(siteId) {
    payrollState.selectedSiteId = Number(siteId);
    renderPayrollDetails();
    document.getElementById('sitesPage')?.classList.remove('active');
    document.getElementById('payrollDetailsPage')?.classList.add('active');
    document.getElementById('successMessage')?.classList.remove('active');
}

function goBackToSites() {
    document.getElementById('payrollDetailsPage')?.classList.remove('active');
    document.getElementById('sitesPage')?.classList.add('active');
    document.getElementById('successMessage')?.classList.remove('active');
}

function updateSummaryCards() {
    const summary = payrollState.summary;
    if (!summary) {
        return;
    }

    const sitesEl = document.getElementById('payrollSitesCount');
    const workersEl = document.getElementById('payrollWorkersCount');
    const processedEl = document.getElementById('processedSitesCount');

    if (sitesEl) {
        sitesEl.textContent = summary.sites;
    }
    if (workersEl) {
        workersEl.textContent = summary.workers;
    }
    if (processedEl) {
        processedEl.textContent = summary.processed;
    }
}

async function processPayroll() {
    const site = getSelectedSite();
    if (!site || site.processed) {
        return;
    }

    const button = document.getElementById('btnProcessPayroll');
    const successMessage = document.getElementById('successMessage');
    const successText = document.getElementById('successMessageText');

    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Processing...</span>';
    }

    try {
        const response = await fetch('../api/process_payroll.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                site_id: site.SiteID,
                period_start: payrollState.period.start,
                period_end: payrollState.period.end
            })
        });

        const result = await response.json();
        if (!result.success) {
            throw new Error(result.message || 'Payroll processing failed');
        }

        site.processed = true;
        payrollState.summary.processed += 1;
        updateSummaryCards();
        renderSiteCards();
        renderPayrollDetails();

        if (successText) {
            successText.textContent = `${result.site_name} payroll processed successfully for ${payrollState.period.label}.`;
        }
        successMessage?.classList.add('active');
        successMessage?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (error) {
        alert(error.message || 'Failed to process payroll');
    } finally {
        if (button) {
            button.disabled = getSelectedSite()?.processed || false;
            button.innerHTML = '<i class="fas fa-money-check-dollar"></i><span>Process Payroll</span>';
        }
    }
}

function printDownloadPayroll() {
    window.print();
}

function bindPayrollEvents() {
    document.addEventListener('click', (event) => {
        const siteButton = event.target.closest('.btn-view-details');
        if (siteButton) {
            viewPayrollDetails(siteButton.dataset.siteId);
            return;
        }
    });

    document.getElementById('btnBackToSites')?.addEventListener('click', goBackToSites);
    document.getElementById('btnProcessPayroll')?.addEventListener('click', processPayroll);
    document.getElementById('btnPrintPayroll')?.addEventListener('click', printDownloadPayroll);
}

document.addEventListener('DOMContentLoaded', () => {
    updateDateTime();
    setInterval(updateDateTime, 60000);

    if (!window.payrollPageData) {
        return;
    }

    payrollState.sites = Array.isArray(window.payrollPageData.sites) ? window.payrollPageData.sites : [];
    payrollState.summary = window.payrollPageData.summary || null;
    payrollState.period = window.payrollPageData.period || null;

    renderSiteCards();
    updateSummaryCards();
    bindPayrollEvents();
});
