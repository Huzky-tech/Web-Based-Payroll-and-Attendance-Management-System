function updateDateTime() {
    const dateEl = document.getElementById('currentDate');
    const timeEl = document.getElementById('currentTime');
    if (!dateEl || !timeEl) {
        return;
    }

    const now = new Date();
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;

    dateEl.textContent = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    timeEl.textContent = `${hours}:${minutes} ${ampm}`;
}

function switchTab(tab) {
    document.querySelectorAll('.pill-tab').forEach((button) => button.classList.remove('active'));
    document.querySelector(`[data-tab="${tab}"]`)?.classList.add('active');

    document.querySelectorAll('.panel').forEach((panel) => {
        if (panel.id) {
            panel.style.display = panel.id === tab ? 'block' : 'none';
        }
    });
}

function handleOvertimeToggle() {
    const overtimeToggle = document.getElementById('allow_overtime');
    const overtimeRateInput = document.getElementById('overtime_rate');
    if (!overtimeToggle || !overtimeRateInput) {
        return;
    }

    overtimeRateInput.disabled = !overtimeToggle.checked;
    overtimeRateInput.style.opacity = overtimeToggle.checked ? '1' : '0.5';
}

function handleNightDiffToggle() {
    const nightDiffToggle = document.getElementById('allow_night_diff');
    const nightDiffRateInput = document.getElementById('night_diff_rate');
    if (!nightDiffToggle || !nightDiffRateInput) {
        return;
    }

    nightDiffRateInput.disabled = !nightDiffToggle.checked;
    nightDiffRateInput.style.opacity = nightDiffToggle.checked ? '1' : '0.5';
}

function validateCompanyInfo() {
    const companyName = document.getElementById('company_name')?.value.trim() || '';
    const taxId = document.getElementById('tax_id')?.value.trim() || '';
    const phone = document.getElementById('phone')?.value.trim() || '';
    const email = document.getElementById('email')?.value.trim() || '';

    const errors = [];
    if (!companyName) {
        errors.push('Company Name is required');
    }
    if (!taxId) {
        errors.push('Tax ID Number is required');
    }
    if (phone && !/^[\d\s\-()+]+$/.test(phone)) {
        errors.push('Phone Number format is invalid');
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push('Email Address format is invalid');
    }

    return errors;
}

function validatePayrollSettings() {
    const payPeriods = document.getElementById('pay_periods')?.value || '';
    const philhealthRate = (document.getElementById('philhealth_rate')?.value || '').replace('%', '');
    const pagibigRate = (document.getElementById('pagibig_rate')?.value || '').replace('%', '');
    const overtimeRate = document.getElementById('overtime_rate')?.value || '';
    const nightDiffRate = document.getElementById('night_diff_rate')?.value || '';

    const errors = [];
    if (!payPeriods) {
        errors.push('Pay Periods is required');
    }

    const philhealth = parseFloat(philhealthRate);
    if (Number.isNaN(philhealth) || philhealth < 0 || philhealth > 100) {
        errors.push('PhilHealth Rate must be a number between 0 and 100');
    }

    const pagibig = parseFloat(pagibigRate);
    if (Number.isNaN(pagibig) || pagibig < 0 || pagibig > 100) {
        errors.push('Pag-IBIG Rate must be a number between 0 and 100');
    }

    if (document.getElementById('allow_overtime')?.checked) {
        const otRate = parseFloat(overtimeRate);
        if (Number.isNaN(otRate) || otRate <= 0) {
            errors.push('Overtime Rate must be greater than 0');
        }
    }

    if (document.getElementById('allow_night_diff')?.checked) {
        const ndRate = parseFloat(nightDiffRate);
        if (Number.isNaN(ndRate) || ndRate <= 0) {
            errors.push('Night Differential Rate must be greater than 0');
        }
    }

    return errors;
}

function validateNotificationSettings() {
    const emailNotifications = document.getElementById('email_notifications')?.checked;
    const inSystemNotifications = document.getElementById('in_system_notifications')?.checked;
    const frequency = document.getElementById('email_digest_frequency')?.value || '';

    const errors = [];
    if (!emailNotifications && !inSystemNotifications) {
        errors.push('Please enable at least one notification channel (Email or In-System)');
    }

    if (emailNotifications && !['Instant', 'Daily', 'Weekly'].includes(frequency)) {
        errors.push('Please select a valid Email Digest Frequency');
    }

    return errors;
}

function handleLogoPreview(input) {
    if (!input.files || !input.files[0]) {
        return;
    }

    const file = input.files[0];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/svg+xml'];
    if (!allowedTypes.includes(file.type)) {
        alert('Please select a valid image file (JPG, PNG, or SVG)');
        input.value = '';
        return;
    }

    if (file.size > 2 * 1024 * 1024) {
        alert('File size too large. Maximum size is 2MB');
        input.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const previewContainer = document.getElementById('logo_preview');
        if (previewContainer) {
            previewContainer.innerHTML = `<img src="${event.target.result}" style="width:70px; height:70px; border-radius:10px; object-fit:cover;">`;
        }
    };
    reader.readAsDataURL(file);
}

async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    return response.json();
}

async function loadCompanySettings() {
    const data = await fetchJson('../api/get_company_settings.php');
    if (!data.success || !data.data) {
        return;
    }

    document.getElementById('company_name').value = data.data.company_name || '';
    document.getElementById('tax_id').value = data.data.tax_id || '';
    document.getElementById('phone').value = data.data.phone || '';
    document.getElementById('email').value = data.data.email || '';
    document.getElementById('address').value = data.data.address || '';

    if (data.data.logo_path) {
        const previewContainer = document.getElementById('logo_preview');
        if (previewContainer) {
            previewContainer.innerHTML = `<img src="../${data.data.logo_path}" style="width:70px; height:70px; border-radius:10px; object-fit:cover;">`;
        }
    }
}

async function loadPayrollSettings() {
    const data = await fetchJson('../api/get_payroll_settings.php');
    if (!data.success || !data.data) {
        return;
    }

    document.getElementById('pay_periods').value = data.data.pay_periods || 'Semi-monthly (1-15, 16-end)';
    document.getElementById('sss_rate').value = data.data.sss_rate || 'Standard';
    document.getElementById('philhealth_rate').value = String(data.data.philhealth_rate || '3');
    document.getElementById('pagibig_rate').value = String(data.data.pagibig_rate || '2');
    document.getElementById('tax_table').value = data.data.tax_table || 'Latest BIR Tax Table';
    document.getElementById('allow_overtime').checked = Number(data.data.allow_overtime) === 1;
    document.getElementById('allow_night_diff').checked = Number(data.data.allow_night_diff) === 1;
    document.getElementById('overtime_rate').value = data.data.overtime_rate || '1.25';
    document.getElementById('night_diff_rate').value = data.data.night_diff_rate || '1.1';

    handleOvertimeToggle();
    handleNightDiffToggle();
}

async function loadNotificationSettings() {
    const data = await fetchJson('../api/get_notification_settings.php');
    if (!data.success || !data.data) {
        return;
    }

    document.getElementById('email_notifications').checked = Number(data.data.email_notifications) === 1;
    document.getElementById('in_system_notifications').checked = Number(data.data.in_system_notifications) === 1;
    document.getElementById('leave_request_updates').checked = Number(data.data.leave_request_updates) === 1;
    document.getElementById('payroll_processing').checked = Number(data.data.payroll_processing) === 1;
    document.getElementById('attendance_issues').checked = Number(data.data.attendance_issues) === 1;
    document.getElementById('system_updates').checked = Number(data.data.system_updates) === 1;
    document.getElementById('daily_reports').checked = Number(data.data.daily_reports) === 1;
    document.getElementById('email_digest_frequency').value = data.data.email_digest_frequency || 'Daily';
}

async function loadSecuritySettings() {
    const data = await fetchJson('../api/get_security_settings.php');
    if (!data.success || !data.data) {
        return;
    }

    document.getElementById('password_expiry_days').value = data.data.password_expiry_days || 90;
    document.getElementById('min_password_length').value = data.data.min_password_length || 8;
    document.getElementById('require_special_char').checked = Number(data.data.require_special_char) === 1;
    document.getElementById('require_number').checked = Number(data.data.require_number) === 1;
    document.getElementById('require_uppercase').checked = Number(data.data.require_uppercase) === 1;
    document.getElementById('max_login_attempts').value = data.data.max_login_attempts || 5;
    document.getElementById('session_timeout_minutes').value = data.data.session_timeout_minutes || 30;
    document.getElementById('enable_2fa').checked = Number(data.data.enable_2fa) === 1;
    document.getElementById('enable_ip_restriction').checked = Number(data.data.enable_ip_restriction) === 1;
}

async function loadSystemSettings() {
    const data = await fetchJson('../api/get_system_settings.php');
    if (!data.success || !data.data) {
        return;
    }

    document.getElementById('maintenance_mode').checked = Number(data.data.maintenance_mode) === 1;
    document.getElementById('debug_mode').checked = Number(data.data.debug_mode) === 1;
    document.getElementById('data_retention_days').value = data.data.data_retention_days || 365;
    document.getElementById('backup_schedule').value = data.data.backup_schedule || 'Daily';
    document.getElementById('timezone').value = data.data.timezone || 'Asia/Manila (GMT+8)';
    document.getElementById('date_format').value = data.data.date_format || 'MM/DD/YYYY';
    document.getElementById('time_format').value = data.data.time_format || '12-hour (AM/PM)';
}

async function loadAllSettings() {
    try {
        await Promise.all([
            loadCompanySettings(),
            loadPayrollSettings(),
            loadNotificationSettings(),
            loadSecuritySettings(),
            loadSystemSettings()
        ]);
    } catch (error) {
        console.error('Error loading settings:', error);
        alert('Some settings failed to load. Please refresh and try again.');
    }
}

async function saveCompanySettings() {
    const companyForm = new FormData();
    companyForm.append('company_name', document.getElementById('company_name').value.trim());
    companyForm.append('tax_id', document.getElementById('tax_id').value.trim());
    companyForm.append('phone', document.getElementById('phone').value.trim());
    companyForm.append('email', document.getElementById('email').value.trim());
    companyForm.append('address', document.getElementById('address').value.trim());

    const logoInput = document.getElementById('company_logo');
    if (logoInput?.files?.[0]) {
        companyForm.append('logo', logoInput.files[0]);
    }

    return fetchJson('../api/update_company_settings.php', {
        method: 'POST',
        body: companyForm
    });
}

async function savePayrollSettings() {
    const payrollForm = new FormData();
    payrollForm.append('pay_periods', document.getElementById('pay_periods').value);
    payrollForm.append('sss_rate', document.getElementById('sss_rate').value);
    payrollForm.append('philhealth_rate', (document.getElementById('philhealth_rate').value || '').replace('%', '') || '3');
    payrollForm.append('pagibig_rate', (document.getElementById('pagibig_rate').value || '').replace('%', '') || '2');
    payrollForm.append('tax_table', document.getElementById('tax_table').value);
    payrollForm.append('allow_overtime', document.getElementById('allow_overtime').checked ? '1' : '0');
    payrollForm.append('allow_night_diff', document.getElementById('allow_night_diff').checked ? '1' : '0');
    payrollForm.append('overtime_rate', document.getElementById('overtime_rate').value || '1.25');
    payrollForm.append('night_diff_rate', document.getElementById('night_diff_rate').value || '1.1');

    return fetchJson('../api/update_payroll_settings.php', {
        method: 'POST',
        body: payrollForm
    });
}

async function saveNotificationSettings() {
    const notificationErrors = validateNotificationSettings();
    if (notificationErrors.length > 0) {
        return { success: false, message: notificationErrors.join(', ') };
    }

    const notificationForm = new FormData();
    notificationForm.append('email_notifications', document.getElementById('email_notifications').checked ? '1' : '0');
    notificationForm.append('in_system_notifications', document.getElementById('in_system_notifications').checked ? '1' : '0');
    notificationForm.append('leave_request_updates', document.getElementById('leave_request_updates').checked ? '1' : '0');
    notificationForm.append('payroll_processing', document.getElementById('payroll_processing').checked ? '1' : '0');
    notificationForm.append('attendance_issues', document.getElementById('attendance_issues').checked ? '1' : '0');
    notificationForm.append('system_updates', document.getElementById('system_updates').checked ? '1' : '0');
    notificationForm.append('daily_reports', document.getElementById('daily_reports').checked ? '1' : '0');
    notificationForm.append('email_digest_frequency', document.getElementById('email_digest_frequency').value);

    return fetchJson('../api/update_notification_settings.php', {
        method: 'POST',
        body: notificationForm
    });
}

async function saveSecuritySettings() {
    const securityForm = new FormData();
    securityForm.append('password_expiry_days', document.getElementById('password_expiry_days').value || '90');
    securityForm.append('min_password_length', document.getElementById('min_password_length').value || '8');
    securityForm.append('require_special_char', document.getElementById('require_special_char').checked ? '1' : '0');
    securityForm.append('require_number', document.getElementById('require_number').checked ? '1' : '0');
    securityForm.append('require_uppercase', document.getElementById('require_uppercase').checked ? '1' : '0');
    securityForm.append('max_login_attempts', document.getElementById('max_login_attempts').value || '5');
    securityForm.append('session_timeout_minutes', document.getElementById('session_timeout_minutes').value || '30');
    securityForm.append('enable_2fa', document.getElementById('enable_2fa').checked ? '1' : '0');
    securityForm.append('enable_ip_restriction', document.getElementById('enable_ip_restriction').checked ? '1' : '0');

    return fetchJson('../api/update_security_settings.php', {
        method: 'POST',
        body: securityForm
    });
}

async function saveSystemSettings() {
    const systemForm = new FormData();
    systemForm.append('maintenance_mode', document.getElementById('maintenance_mode').checked ? '1' : '0');
    systemForm.append('debug_mode', document.getElementById('debug_mode').checked ? '1' : '0');
    systemForm.append('data_retention_days', document.getElementById('data_retention_days').value || '365');
    systemForm.append('backup_schedule', document.getElementById('backup_schedule').value);
    systemForm.append('timezone', document.getElementById('timezone').value);
    systemForm.append('date_format', document.getElementById('date_format').value);
    systemForm.append('time_format', document.getElementById('time_format').value);

    return fetchJson('../api/update_system_settings.php', {
        method: 'POST',
        body: systemForm
    });
}

async function saveAll() {
    const companyErrors = validateCompanyInfo();
    if (companyErrors.length > 0) {
        alert(`Please fix the following errors in Company tab:\n\n${companyErrors.join('\n')}`);
        switchTab('company');
        return;
    }

    const payrollErrors = validatePayrollSettings();
    if (payrollErrors.length > 0) {
        alert(`Please fix the following errors in Payroll tab:\n\n${payrollErrors.join('\n')}`);
        switchTab('payroll');
        return;
    }

    const notificationErrors = validateNotificationSettings();
    if (notificationErrors.length > 0) {
        alert(`Please fix the following errors in Notifications tab:\n\n${notificationErrors.join('\n')}`);
        switchTab('notifications');
        return;
    }

    if (!confirm('Are you sure you want to save all settings?')) {
        return;
    }

    try {
        const results = await Promise.all([
            saveCompanySettings(),
            savePayrollSettings(),
            saveNotificationSettings(),
            saveSecuritySettings(),
            saveSystemSettings()
        ]);

        const failed = results.filter((result) => !result.success);
        if (failed.length > 0) {
            alert(`Some settings failed to save:\n\n${failed.map((result) => result.message).join('\n')}`);
            return;
        }

        alert('All settings saved successfully.');
        await loadAllSettings();
    } catch (error) {
        console.error('Error saving settings:', error);
        alert('Error saving settings. Please try again.');
    }
}

function openAddUserModal() {
    document.getElementById('addUserModal').style.display = 'flex';
}

function closeAddUserModal() {
    document.getElementById('addUserModal').style.display = 'none';
    document.getElementById('newUserName').value = '';
    document.getElementById('newUserEmail').value = '';
    document.getElementById('newUserRole').value = 'Payroll Staff';
    document.getElementById('newUserPassword').value = '';
    document.getElementById('newUserPasswordConfirm').value = '';
    document.getElementById('newUserPassword').classList.remove('password-error', 'password-success');
    document.getElementById('newUserPasswordConfirm').classList.remove('password-error', 'password-success');
    document.getElementById('passwordError').classList.remove('show');
    document.getElementById('confirmPasswordError').classList.remove('show');
}

function togglePassword(fieldId, button) {
    const field = document.getElementById(fieldId);
    const icon = button.querySelector('i');
    if (!field || !icon) {
        return;
    }

    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

function validatePasswords() {
    const password = document.getElementById('newUserPassword').value;
    const confirmPassword = document.getElementById('newUserPasswordConfirm').value;
    const passwordField = document.getElementById('newUserPassword');
    const confirmField = document.getElementById('newUserPasswordConfirm');
    const passwordError = document.getElementById('passwordError');
    const confirmError = document.getElementById('confirmPasswordError');

    passwordField.classList.remove('password-error', 'password-success');
    confirmField.classList.remove('password-error', 'password-success');
    passwordError.classList.remove('show');
    confirmError.classList.remove('show');

    if (password && password.length < 8) {
        passwordField.classList.add('password-error');
        passwordError.textContent = 'Password must be at least 8 characters long.';
        passwordError.classList.add('show');
    } else if (password) {
        passwordField.classList.add('password-success');
    }

    if (confirmPassword) {
        if (password !== confirmPassword) {
            confirmField.classList.add('password-error');
            confirmError.textContent = 'Passwords do not match.';
            confirmError.classList.add('show');
        } else if (password.length >= 8) {
            confirmField.classList.add('password-success');
        }
    }
}

async function handleAddUser() {
    const name = document.getElementById('newUserName').value.trim();
    const email = document.getElementById('newUserEmail').value.trim();
    const role = document.getElementById('newUserRole').value;
    const password = document.getElementById('newUserPassword').value;
    const confirm = document.getElementById('newUserPasswordConfirm').value;

    if (!name || !email || !role || !password || !confirm) {
        alert('Please fill in all fields.');
        return;
    }

    if (password.length < 8) {
        alert('Password must be at least 8 characters long.');
        return;
    }

    if (password !== confirm) {
        alert('Passwords do not match.');
        validatePasswords();
        return;
    }

    const formData = new FormData();
    formData.append('full_name', name);
    formData.append('email', email);
    formData.append('role', role);
    formData.append('password', password);

    const data = await fetchJson('../api/add_user.php', {
        method: 'POST',
        body: formData
    });

    alert(data.message);
    if (data.success) {
        await loadUsers();
        closeAddUserModal();
    }
}

async function loadUsers() {
    try {
        const data = await fetchJson('../api/get_users.php');
        if (!data.success) {
            return;
        }

        const tbody = document.getElementById('usersTableBody');
        if (!tbody) {
            return;
        }

        tbody.innerHTML = '';
        data.data.forEach((user) => {
            const tr = document.createElement('tr');
            const roleLabel = user.role === 'Payroll Staff' ? 'Payroll' : user.role;
            const statusClass = user.status === 'Active' ? 'green' : 'red';
            const lastLogin = user.last_login ? new Date(user.last_login).toLocaleString() : 'Never';
            const escapedName = JSON.stringify(user.full_name || '');
            const escapedEmail = JSON.stringify(user.email || '');
            const escapedRole = JSON.stringify(user.role || 'Worker');
            const escapedStatus = JSON.stringify(user.status || 'Active');

            tr.innerHTML = `
                <td><strong>${user.full_name}</strong><div class="muted">${user.email}</div></td>
                <td><span class="badge" style="background:#fef3c7;color:#b45309;">${roleLabel}</span></td>
                <td><span class="badge ${statusClass}">${user.status}</span></td>
                <td>${lastLogin}</td>
                <td class="actions">
                    <button class="icon-btn" onclick='openEditUserModal(${user.id}, ${escapedName}, ${escapedEmail}, ${escapedRole}, ${escapedStatus})'><i class="fas fa-pen"></i></button>
                    <button class="icon-btn" onclick="copyUser(${user.id})"><i class="fas fa-copy"></i></button>
                    <button class="icon-btn delete" onclick="deleteUser(${user.id})"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

function openEditUserModal(userId, userName, userEmail, userRole, userStatus) {
    document.getElementById('editUserId').value = userId;
    document.getElementById('editUserName').value = userName;
    document.getElementById('editUserEmail').value = userEmail;
    document.getElementById('editUserRole').value = userRole;
    document.getElementById('editUserStatus').value = userStatus;
    document.getElementById('editUserModal').style.display = 'flex';
}

function closeEditUserModal() {
    document.getElementById('editUserModal').style.display = 'none';
    document.getElementById('editUserId').value = '';
    document.getElementById('editUserName').value = '';
    document.getElementById('editUserEmail').value = '';
    document.getElementById('editUserRole').value = 'Payroll Staff';
    document.getElementById('editUserStatus').value = 'Active';
}

async function handleEditUser() {
    const userId = document.getElementById('editUserId').value;
    const name = document.getElementById('editUserName').value.trim();
    const email = document.getElementById('editUserEmail').value.trim();
    const role = document.getElementById('editUserRole').value;
    const status = document.getElementById('editUserStatus').value;

    if (!userId || !name || !email || !role || !status) {
        alert('Please fill in all required fields.');
        return;
    }

    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('full_name', name);
    formData.append('email', email);
    formData.append('role', role);
    formData.append('status', status);

    const data = await fetchJson('../api/edit_user.php', {
        method: 'POST',
        body: formData
    });

    alert(data.message);
    if (data.success) {
        await loadUsers();
        closeEditUserModal();
    }
}

async function copyUser(userId) {
    try {
        const data = await fetchJson('../api/get_users.php');
        if (!data.success) {
            return;
        }

        const user = data.data.find((entry) => Number(entry.id) === Number(userId));
        if (!user) {
            alert('User not found.');
            return;
        }

        await navigator.clipboard.writeText(`${user.full_name} <${user.email}>`);
        alert('User details copied to clipboard.');
    } catch (error) {
        console.error('Copy user failed:', error);
        alert('Unable to copy user details.');
    }
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to deactivate this user?')) {
        return;
    }

    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('current_user_id', 0);

    const data = await fetchJson('../api/delete_user.php', {
        method: 'POST',
        body: formData
    });

    alert(data.message);
    if (data.success) {
        await loadUsers();
    }
}

async function runBackup() {
    const data = await fetchJson('../api/backup_system.php', { method: 'POST' });
    alert(data.message);
}

async function clearSystemCache() {
    const data = await fetchJson('../api/clear_cache.php', { method: 'POST' });
    alert(data.message);
}

async function terminateSessions() {
    if (!confirm('Terminate all active sessions?')) {
        return;
    }
    const data = await fetchJson('../api/terminate_sessions.php', { method: 'POST' });
    alert(data.message);
}

async function resetAllSettings() {
    if (!confirm('Reset all settings to defaults?')) {
        return;
    }

    const data = await fetchJson('../api/reset_settings.php', { method: 'POST' });
    alert(data.message);
    if (data.success) {
        await loadAllSettings();
    }
}

async function forcePasswordReset() {
    if (!confirm('Force password reset for all active users?')) {
        return;
    }
    const data = await fetchJson('../api/force_password_reset.php', { method: 'POST' });
    alert(data.message);
}

document.addEventListener('DOMContentLoaded', async function () {
    updateDateTime();
    setInterval(updateDateTime, 60000);

    document.getElementById('allow_overtime')?.addEventListener('change', handleOvertimeToggle);
    document.getElementById('allow_night_diff')?.addEventListener('change', handleNightDiffToggle);

    handleOvertimeToggle();
    handleNightDiffToggle();

    await loadAllSettings();
    await loadUsers();
});

window.switchTab = switchTab;
window.handleOvertimeToggle = handleOvertimeToggle;
window.handleNightDiffToggle = handleNightDiffToggle;
window.handleLogoPreview = handleLogoPreview;
window.saveAll = saveAll;
window.openAddUserModal = openAddUserModal;
window.closeAddUserModal = closeAddUserModal;
window.togglePassword = togglePassword;
window.validatePasswords = validatePasswords;
window.handleAddUser = handleAddUser;
window.openEditUserModal = openEditUserModal;
window.closeEditUserModal = closeEditUserModal;
window.handleEditUser = handleEditUser;
window.copyUser = copyUser;
window.deleteUser = deleteUser;
window.runBackup = runBackup;
window.clearSystemCache = clearSystemCache;
window.terminateSessions = terminateSessions;
window.resetAllSettings = resetAllSettings;
window.forcePasswordReset = forcePasswordReset;
window.loadAllSettings = loadAllSettings;
